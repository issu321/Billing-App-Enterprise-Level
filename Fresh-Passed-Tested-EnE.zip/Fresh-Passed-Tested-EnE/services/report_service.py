"""Reporting and Analytics Service"""
from models import db
from models.sale import Sale, SaleItem
from models.purchase import Purchase
from models.product import Product
from models.customer import Customer, CustomerLedger
from models.supplier import Supplier
from models.inventory import Inventory, InventoryTransaction
from sqlalchemy import func, extract
from datetime import datetime, timedelta


class ReportService:
    """Service for generating reports and analytics"""
    
    @staticmethod
    def get_dashboard_summary():
        """Get dashboard summary data"""
        from utils.helpers import get_date_range
        
        today_start, today_end = get_date_range('today')
        week_start, week_end = get_date_range('week')
        month_start, month_end = get_date_range('month')
        
        # Today's sales
        today_sales = db.session.query(func.count(Sale.id), func.sum(Sale.total_amount)).filter(
            Sale.created_at.between(today_start, today_end),
            Sale.status != 'cancelled'
        ).first()
        
        # Week's sales
        week_sales = db.session.query(func.sum(Sale.total_amount)).filter(
            Sale.created_at.between(week_start, week_end),
            Sale.status != 'cancelled'
        ).scalar() or 0
        
        # Month's sales
        month_sales = db.session.query(func.sum(Sale.total_amount)).filter(
            Sale.created_at.between(month_start, month_end),
            Sale.status != 'cancelled'
        ).scalar() or 0
        
        # Total products
        total_products = Product.query.filter_by(is_active=True).count()
        
        # Low stock
        low_stock = db.session.query(Inventory).join(Product).filter(
            Inventory.quantity <= Product.reorder_level,
            Product.is_active == True
        ).count()
        
        # Total customers
        total_customers = Customer.query.filter_by(is_active=True).count()
        total_suppliers = Supplier.query.filter_by(is_active=True).count()
        
        # Pending purchases
        pending_purchases = Purchase.query.filter_by(status='ordered').count()
        
        # Balance due
        balance_due = db.session.query(func.sum(Sale.balance_amount)).filter(
            Sale.status != 'cancelled'
        ).scalar() or 0
        
        return {
            'today_sales_count': today_sales[0] or 0,
            'today_sales_amount': float(today_sales[1] or 0),
            'week_sales_amount': float(week_sales),
            'month_sales_amount': float(month_sales),
            'total_products': total_products,
            'low_stock_count': low_stock,
            'total_customers': total_customers,
            'total_suppliers': total_suppliers,
            'pending_purchases': pending_purchases,
            'balance_due': float(balance_due)
        }
    
    @staticmethod
    def get_sales_report(date_from=None, date_to=None, group_by='day', customer_id=None, product_id=None):
        """Get detailed sales report"""
        query = Sale.query.filter(Sale.status != 'cancelled')
        
        if date_from:
            query = query.filter(Sale.created_at >= date_from)
        if date_to:
            query = query.filter(Sale.created_at <= date_to)
        if customer_id:
            query = query.filter(Sale.customer_id == customer_id)
        
        sales = query.all()
        
        total_amount = sum(float(s.total_amount) for s in sales)
        total_paid = sum(float(s.paid_amount) for s in sales)
        total_discount = sum(float(s.discount_amount) for s in sales)
        total_tax = sum(float(s.tax_amount) for s in sales)
        
        return {
            'total_sales': len(sales),
            'total_amount': total_amount,
            'total_paid': total_paid,
            'total_balance': total_amount - total_paid,
            'total_discount': total_discount,
            'total_tax': total_tax,
            'sales': [s.to_dict() for s in sales[:100]]  # Limit to 100
        }
    
    @staticmethod
    def get_sales_by_period(period='daily', months=6):
        """Get sales grouped by period for charts"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30*months)
        
        if period == 'daily':
            results = db.session.query(
                func.date(Sale.created_at).label('period'),
                func.count(Sale.id).label('count'),
                func.sum(Sale.total_amount).label('amount')
            ).filter(
                Sale.created_at.between(start_date, end_date),
                Sale.status != 'cancelled'
            ).group_by(func.date(Sale.created_at)).order_by('period').all()
        
        elif period == 'monthly':
            results = db.session.query(
                func.strftime('%Y-%m', Sale.created_at).label('period'),
                func.count(Sale.id).label('count'),
                func.sum(Sale.total_amount).label('amount')
            ).filter(
                Sale.created_at.between(start_date, end_date),
                Sale.status != 'cancelled'
            ).group_by(func.strftime('%Y-%m', Sale.created_at)).order_by('period').all()
        
        else:  # weekly
            results = db.session.query(
                func.strftime('%Y-%W', Sale.created_at).label('period'),
                func.count(Sale.id).label('count'),
                func.sum(Sale.total_amount).label('amount')
            ).filter(
                Sale.created_at.between(start_date, end_date),
                Sale.status != 'cancelled'
            ).group_by(func.strftime('%Y-%W', Sale.created_at)).order_by('period').all()
        
        return [{
            'period': r.period,
            'count': r.count,
            'amount': float(r.amount) if r.amount else 0
        } for r in results]
    
    @staticmethod
    def get_product_performance(limit=20, date_from=None, date_to=None):
        """Get product performance report"""
        query = db.session.query(
            SaleItem.product_id,
            SaleItem.product_name,
            func.sum(SaleItem.quantity).label('total_qty'),
            func.sum(SaleItem.total_price).label('total_revenue'),
            func.avg(SaleItem.unit_price).label('avg_price')
        ).join(Sale).filter(Sale.status != 'cancelled')
        
        if date_from:
            query = query.filter(Sale.created_at >= date_from)
        if date_to:
            query = query.filter(Sale.created_at <= date_to)
        
        results = query.group_by(SaleItem.product_id).order_by(
            func.sum(SaleItem.quantity).desc()
        ).limit(limit).all()
        
        return [{
            'product_id': r.product_id,
            'product_name': r.product_name,
            'total_quantity': float(r.total_qty) if r.total_qty else 0,
            'total_revenue': float(r.total_revenue) if r.total_revenue else 0,
            'average_price': float(r.avg_price) if r.avg_price else 0
        } for r in results]
    
    @staticmethod
    def get_customer_report(limit=20, date_from=None, date_to=None):
        """Get customer report"""
        query = db.session.query(
            Sale.customer_id,
            Sale.customer_name,
            func.count(Sale.id).label('purchase_count'),
            func.sum(Sale.total_amount).label('total_amount'),
            func.avg(Sale.total_amount).label('avg_order')
        ).filter(Sale.status != 'cancelled')
        
        if date_from:
            query = query.filter(Sale.created_at >= date_from)
        if date_to:
            query = query.filter(Sale.created_at <= date_to)
        
        results = query.group_by(Sale.customer_id).order_by(
            func.sum(Sale.total_amount).desc()
        ).limit(limit).all()
        
        return [{
            'customer_id': r.customer_id,
            'customer_name': r.customer_name or 'Walk-in',
            'purchase_count': r.purchase_count,
            'total_amount': float(r.total_amount) if r.total_amount else 0,
            'avg_order': float(r.avg_order) if r.avg_order else 0
        } for r in results]
    
    @staticmethod
    def get_inventory_report(warehouse_id=None):
        """Get inventory valuation report"""
        query = Inventory.query.join(Product)
        
        if warehouse_id:
            query = query.filter(Inventory.warehouse_id == warehouse_id)
        
        inventory_items = query.all()
        
        total_value = 0
        total_items = 0
        items = []
        
        for inv in inventory_items:
            cost = float(inv.product.cost_price) if inv.product and inv.product.cost_price else 0
            qty = float(inv.quantity) if inv.quantity else 0
            value = cost * qty
            
            total_value += value
            total_items += qty
            
            items.append({
                'product_id': inv.product_id,
                'product_name': inv.product.name if inv.product else 'Unknown',
                'sku': inv.product.sku if inv.product else '',
                'warehouse': inv.warehouse.name if inv.warehouse else '',
                'quantity': qty,
                'cost_price': cost,
                'value': value,
                'status': 'low' if inv.product and qty <= float(inv.product.reorder_level) else 'ok'
            })
        
        return {
            'total_items': total_items,
            'total_value': total_value,
            'items': sorted(items, key=lambda x: x['value'], reverse=True)
        }
    
    @staticmethod
    def get_payment_report(date_from=None, date_to=None):
        """Get payment summary report"""
        query = Sale.query.filter(Sale.status != 'cancelled')
        
        if date_from:
            query = query.filter(Sale.created_at >= date_from)
        if date_to:
            query = query.filter(Sale.created_at <= date_to)
        
        sales = query.all()
        
        by_method = {}
        by_status = {}
        
        for sale in sales:
            method = sale.payment_method or 'cash'
            by_method[method] = by_method.get(method, 0) + float(sale.total_amount)
            
            status = sale.payment_status or 'pending'
            by_status[status] = by_status.get(status, 0) + float(sale.total_amount)
        
        return {
            'total_sales': len(sales),
            'total_amount': sum(float(s.total_amount) for s in sales),
            'total_paid': sum(float(s.paid_amount) for s in sales),
            'total_balance': sum(float(s.balance_amount) for s in sales),
            'by_method': by_method,
            'by_status': by_status
        }
    
    @staticmethod
    def get_yearly_comparison():
        """Get year-over-year comparison"""
        current_year = datetime.now().year
        
        result = []
        for year in range(current_year - 2, current_year + 1):
            yearly_sales = db.session.query(func.sum(Sale.total_amount)).filter(
                extract('year', Sale.created_at) == year,
                Sale.status != 'cancelled'
            ).scalar() or 0
            
            yearly_purchases = db.session.query(func.sum(Purchase.total_amount)).filter(
                extract('year', Purchase.created_at) == year
            ).scalar() or 0
            
            result.append({
                'year': year,
                'sales': float(yearly_sales),
                'purchases': float(yearly_purchases),
                'profit': float(yearly_sales) - float(yearly_purchases)
            })
        
        return result
