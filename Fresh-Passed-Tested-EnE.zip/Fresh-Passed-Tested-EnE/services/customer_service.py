"""Customer Management Service"""
from models import db
from models.customer import Customer, CustomerGroup, CustomerLedger
from utils.validators import validate_email, validate_phone, validate_required


class CustomerService:
    """Service for customer management"""
    
    @staticmethod
    def get_all_customers(page=1, per_page=20, search=None, group_id=None, customer_type=None, is_active=None):
        """Get all customers with filters"""
        query = Customer.query
        
        if search:
            query = query.filter(
                db.or_(
                    Customer.name.ilike(f'%{search}%'),
                    Customer.email.ilike(f'%{search}%'),
                    Customer.phone.ilike(f'%{search}%'),
                    Customer.customer_code.ilike(f'%{search}%'),
                    Customer.gst_number.ilike(f'%{search}%')
                )
            )
        
        if group_id:
            query = query.filter(Customer.group_id == group_id)
        if customer_type:
            query = query.filter(Customer.customer_type == customer_type)
        if is_active is not None:
            query = query.filter(Customer.is_active == is_active)
        
        return query.order_by(Customer.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    
    @staticmethod
    def get_customer_by_id(customer_id):
        """Get customer by ID"""
        return Customer.query.get(customer_id)
    
    @staticmethod
    def get_customer_by_phone(phone):
        """Get customer by phone"""
        return Customer.query.filter(
            db.or_(Customer.phone == phone, Customer.mobile == phone)
        ).first()
    
    @staticmethod
    def create_customer(data, created_by=None):
        """Create a new customer"""
        is_valid, message = validate_required(data.get('name'), "Customer name")
        if not is_valid:
            return None, message
        
        # Generate customer code if not provided
        customer_code = data.get('customer_code')
        if not customer_code:
            last_customer = Customer.query.order_by(Customer.id.desc()).first()
            next_id = (last_customer.id + 1) if last_customer else 1
            customer_code = f"CUST{next_id:05d}"
        
        if Customer.query.filter_by(customer_code=customer_code).first():
            return None, "Customer code already exists"
        
        customer = Customer(
            customer_code=customer_code,
            name=data['name'],
            email=data.get('email', ''),
            phone=data.get('phone', ''),
            mobile=data.get('mobile', ''),
            group_id=data.get('group_id'),
            customer_type=data.get('customer_type', 'retail'),
            address=data.get('address'),
            city=data.get('city'),
            state=data.get('state'),
            country=data.get('country'),
            postal_code=data.get('postal_code'),
            gst_number=data.get('gst_number', ''),
            tax_number=data.get('tax_number', ''),
            pan_number=data.get('pan_number', ''),
            credit_limit=data.get('credit_limit', 0),
            credit_days=data.get('credit_days', 0),
            contact_person=data.get('contact_person'),
            contact_phone=data.get('contact_phone'),
            contact_email=data.get('contact_email'),
            date_of_birth=data.get('date_of_birth'),
            anniversary_date=data.get('anniversary_date'),
            notes=data.get('notes'),
            is_active=data.get('is_active', True),
            created_by=created_by
        )
        
        db.session.add(customer)
        db.session.commit()
        
        return customer, "Customer created successfully"
    
    @staticmethod
    def update_customer(customer_id, data):
        """Update customer"""
        customer = Customer.query.get(customer_id)
        if not customer:
            return None, "Customer not found"
        
        updatable_fields = [
            'name', 'email', 'phone', 'mobile', 'group_id', 'customer_type',
            'address', 'city', 'state', 'country', 'postal_code',
            'gst_number', 'tax_number', 'pan_number',
            'credit_limit', 'credit_days',
            'contact_person', 'contact_phone', 'contact_email',
            'date_of_birth', 'anniversary_date', 'notes', 'is_active'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(customer, field, data[field])
        
        db.session.commit()
        return customer, "Customer updated successfully"
    
    @staticmethod
    def delete_customer(customer_id):
        """Delete customer"""
        customer = Customer.query.get(customer_id)
        if not customer:
            return False, "Customer not found"
        
        db.session.delete(customer)
        db.session.commit()
        return True, "Customer deleted successfully"
    
    @staticmethod
    def add_ledger_entry(customer_id, entry_type, amount, reference_type=None, 
                         reference_id=None, reference_number=None, description=None, created_by=None):
        """Add ledger entry for customer"""
        customer = Customer.query.get(customer_id)
        if not customer:
            return None, "Customer not found"
        
        # Calculate new balance
        current_balance = customer.get_balance()
        
        if entry_type in ('sale', 'debit'):
            new_balance = current_balance + float(amount)
        else:
            new_balance = current_balance - float(amount)
        
        entry = CustomerLedger(
            customer_id=customer_id,
            entry_type=entry_type,
            reference_type=reference_type,
            reference_id=reference_id,
            reference_number=reference_number,
            amount=amount,
            balance=new_balance,
            description=description,
            created_by=created_by
        )
        
        db.session.add(entry)
        db.session.commit()
        
        return entry, "Ledger entry added"
    
    @staticmethod
    def get_customer_ledger(customer_id, page=1, per_page=20):
        """Get customer ledger entries"""
        return CustomerLedger.query.filter_by(customer_id=customer_id)\
            .order_by(CustomerLedger.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
    
    @staticmethod
    def get_all_groups():
        """Get all customer groups"""
        return CustomerGroup.query.filter_by(is_active=True).all()
    
    @staticmethod
    def create_group(data):
        """Create customer group"""
        group = CustomerGroup(
            name=data['name'],
            description=data.get('description'),
            discount_percent=data.get('discount_percent', 0),
            price_level=data.get('price_level', 'retail')
        )
        db.session.add(group)
        db.session.commit()
        return group, "Group created"
    
    @staticmethod
    def get_customer_stats():
        """Get customer statistics"""
        total = Customer.query.count()
        active = Customer.query.filter_by(is_active=True).count()
        
        # Top customers by balance
        from sqlalchemy import func
        top_customers = Customer.query.outerjoin(Customer.ledger_entries)\
            .group_by(Customer.id)\
            .order_by(func.sum(CustomerLedger.amount).desc())\
            .limit(5).all()
        
        return {
            'total': total,
            'active': active,
            'top_customers': [c.to_dict() for c in top_customers]
        }
