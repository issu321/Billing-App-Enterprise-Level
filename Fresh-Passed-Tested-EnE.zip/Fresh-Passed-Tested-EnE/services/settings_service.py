"""Settings Management Service"""
from models import db
from models.settings import BusinessSettings, TaxSetting, NotificationSetting, BackupSetting
from models.payment import Currency, Account, PaymentMethod


class SettingsService:
    """Service for managing business settings"""
    
    @staticmethod
    def get_settings():
        """Get current business settings"""
        settings = BusinessSettings.query.first()
        if not settings:
            settings = BusinessSettings()
            db.session.add(settings)
            db.session.commit()
        return settings
    
    @staticmethod
    def update_settings(data):
        """Update business settings"""
        settings = SettingsService.get_settings()
        
        updatable_fields = [
            'business_name', 'store_name', 'tagline',
            'owner_name', 'owner_email', 'owner_phone',
            'address', 'city', 'state', 'country', 'postal_code',
            'gst_number', 'vat_number', 'tin_number', 'pan_number',
            'phone', 'email', 'website',
            'logo', 'favicon', 'receipt_header', 'receipt_footer',
            'currency_id', 'timezone', 'date_format', 'time_format', 'language',
            'invoice_prefix', 'invoice_suffix', 'invoice_starting_number',
            'invoice_terms', 'invoice_footer', 'show_logo_on_invoice', 'auto_email_invoice',
            'default_warehouse_id', 'enable_pos', 'pos_receipt_printer', 'auto_print_receipt',
            'enable_inventory_tracking', 'enable_negative_stock', 'enable_multi_warehouse',
            'enable_barcode', 'enable_qr_payments', 'enable_customer_loyalty',
            'enable_serial_tracking', 'enable_batch_tracking', 'enable_expiry_tracking',
            'default_tax_rate', 'tax_inclusive_pricing', 'enable_multiple_tax',
            'quantity_decimal_places', 'price_decimal_places', 'amount_decimal_places',
            'theme_primary_color', 'theme_secondary_color', 'theme_mode',
            'setup_completed'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(settings, field, data[field])
        
        if data.get('setup_completed') and not settings.setup_completed_at:
            from datetime import datetime
            settings.setup_completed_at = datetime.utcnow()
        
        db.session.commit()
        return settings, "Settings updated successfully"
    
    @staticmethod
    def get_tax_settings():
        """Get all tax settings"""
        return TaxSetting.query.all()
    
    @staticmethod
    def get_default_tax():
        """Get default tax setting"""
        return TaxSetting.query.filter_by(is_default=True, is_active=True).first()
    
    @staticmethod
    def create_tax_setting(data):
        """Create tax setting"""
        tax = TaxSetting(
            name=data['name'],
            tax_type=data.get('tax_type', 'gst'),
            rate=data.get('rate', 0),
            cgst_rate=data.get('cgst_rate', 0),
            sgst_rate=data.get('sgst_rate', 0),
            igst_rate=data.get('igst_rate', 0),
            cess_rate=data.get('cess_rate', 0),
            hsn_code_prefix=data.get('hsn_code_prefix'),
            description=data.get('description'),
            is_default=data.get('is_default', False),
            is_active=data.get('is_active', True)
        )
        
        if tax.is_default:
            # Unset existing default
            TaxSetting.query.update({'is_default': False})
        
        db.session.add(tax)
        db.session.commit()
        return tax, "Tax setting created"
    
    @staticmethod
    def update_tax_setting(tax_id, data):
        """Update tax setting"""
        tax = TaxSetting.query.get(tax_id)
        if not tax:
            return None, "Tax setting not found"
        
        for field in ['name', 'tax_type', 'rate', 'cgst_rate', 'sgst_rate', 
                      'igst_rate', 'cess_rate', 'hsn_code_prefix', 'description', 'is_active']:
            if field in data:
                setattr(tax, field, data[field])
        
        if data.get('is_default'):
            TaxSetting.query.filter(TaxSetting.id != tax_id).update({'is_default': False})
            tax.is_default = True
        
        db.session.commit()
        return tax, "Tax setting updated"
    
    @staticmethod
    def delete_tax_setting(tax_id):
        """Delete tax setting"""
        tax = TaxSetting.query.get(tax_id)
        if not tax:
            return False, "Tax setting not found"
        
        db.session.delete(tax)
        db.session.commit()
        return True, "Tax setting deleted"
    
    @staticmethod
    def get_currencies():
        """Get all currencies"""
        return Currency.query.all()
    
    @staticmethod
    def create_currency(data):
        """Create currency"""
        if Currency.query.filter_by(code=data['code']).first():
            return None, "Currency code already exists"
        
        currency = Currency(
            code=data['code'],
            name=data['name'],
            symbol=data['symbol'],
            exchange_rate=data.get('exchange_rate', 1.0),
            is_base=data.get('is_base', False),
            is_active=data.get('is_active', True)
        )
        
        if currency.is_base:
            Currency.query.update({'is_base': False})
        
        db.session.add(currency)
        db.session.commit()
        return currency, "Currency created"
    
    @staticmethod
    def get_accounts():
        """Get all financial accounts"""
        return Account.query.all()
    
    @staticmethod
    def create_account(data):
        """Create account"""
        account = Account(
            name=data['name'],
            account_number=data.get('account_number'),
            account_type=data['account_type'],
            bank_name=data.get('bank_name'),
            branch_name=data.get('branch_name'),
            ifsc_code=data.get('ifsc_code'),
            swift_code=data.get('swift_code'),
            upi_id=data.get('upi_id'),
            opening_balance=data.get('opening_balance', 0),
            current_balance=data.get('opening_balance', 0),
            currency_id=data.get('currency_id'),
            is_default=data.get('is_default', False),
            is_active=data.get('is_active', True),
            notes=data.get('notes')
        )
        db.session.add(account)
        db.session.commit()
        return account, "Account created"
    
    @staticmethod
    def get_payment_methods():
        """Get all payment methods"""
        return PaymentMethod.query.filter_by(is_active=True).order_by(PaymentMethod.sort_order).all()
    
    @staticmethod
    def create_payment_method(data):
        """Create payment method"""
        method = PaymentMethod(
            name=data['name'],
            code=data['code'],
            description=data.get('description'),
            icon=data.get('icon'),
            requires_reference=data.get('requires_reference', False),
            auto_deposit_account_id=data.get('auto_deposit_account_id'),
            processing_fee_percent=data.get('processing_fee_percent', 0),
            gateway_name=data.get('gateway_name'),
            gateway_config=data.get('gateway_config'),
            is_active=data.get('is_active', True),
            sort_order=data.get('sort_order', 0)
        )
        db.session.add(method)
        db.session.commit()
        return method, "Payment method created"
    
    @staticmethod
    def get_notification_settings():
        """Get notification settings"""
        settings = NotificationSetting.query.first()
        if not settings:
            settings = NotificationSetting()
            db.session.add(settings)
            db.session.commit()
        return settings
    
    @staticmethod
    def get_backup_settings():
        """Get backup settings"""
        settings = BackupSetting.query.first()
        if not settings:
            settings = BackupSetting()
            db.session.add(settings)
            db.session.commit()
        return settings
    
    @staticmethod
    def get_setup_status():
        """Check if initial setup is completed"""
        settings = SettingsService.get_settings()
        return {
            'setup_completed': settings.setup_completed,
            'setup_completed_at': settings.setup_completed_at.isoformat() if settings.setup_completed_at else None
        }
