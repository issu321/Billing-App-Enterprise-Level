"""Product Management Service"""
from models import db
from models.product import Product, ProductVariant, ProductImage, Category, UnitOfMeasure
from models.inventory import Inventory, Warehouse
from utils.validators import validate_required, validate_sku, validate_number
from utils.helpers import generate_code
from datetime import datetime


class ProductService:
    """Service for product management"""
    
    @staticmethod
    def get_or_create_unit(unit_text):
        """Get existing unit or create new one from free text input"""
        if not unit_text or not str(unit_text).strip():
            return None
        
        unit_text = str(unit_text).strip().lower()
        
        # Try to find existing unit by name or code
        existing = UnitOfMeasure.query.filter(
            db.or_(
                db.func.lower(UnitOfMeasure.name) == unit_text,
                db.func.lower(UnitOfMeasure.code) == unit_text
            )
        ).first()
        
        if existing:
            return existing.id
        
        # Create new unit
        new_unit = UnitOfMeasure(
            name=unit_text.capitalize(),
            code=unit_text.upper(),
            description=f'Auto-created unit: {unit_text}'
        )
        db.session.add(new_unit)
        db.session.commit()
        return new_unit.id
    
    @staticmethod
    def get_all_products(page=1, per_page=20, search=None, category_id=None, 
                         stock_status=None, is_active=None, sort_by='created_at', sort_order='desc'):
        """Get all products with filters"""
        query = Product.query
        
        if search:
            query = query.filter(
                db.or_(
                    Product.name.ilike(f'%{search}%'),
                    Product.sku.ilike(f'%{search}%'),
                    Product.barcode.ilike(f'%{search}%'),
                    Product.description.ilike(f'%{search}%'),
                    Product.brand.ilike(f'%{search}%')
                )
            )
        
        if category_id:
            query = query.filter(Product.category_id == category_id)
        
        if is_active is not None:
            query = query.filter(Product.is_active == is_active)
        
        if sort_order == 'desc':
            query = query.order_by(db.desc(getattr(Product, sort_by, Product.created_at)))
        else:
            query = query.order_by(getattr(Product, sort_by, Product.created_at))
        
        return query.paginate(page=page, per_page=per_page, error_out=False)
    
    @staticmethod
    def get_product_by_id(product_id):
        """Get product by ID"""
        return Product.query.get(product_id)
    
    @staticmethod
    def get_product_by_barcode(barcode):
        """Get product by barcode"""
        return Product.query.filter_by(barcode=barcode).first()
    
    @staticmethod
    def get_product_by_sku(sku):
        """Get product by SKU"""
        return Product.query.filter_by(sku=sku).first()
    
    @staticmethod
    def create_product(data, created_by=None):
        """Create a new product"""
        is_valid, message = validate_required(data.get('name'), "Product name")
        if not is_valid:
            return None, message
        
        is_valid, message = validate_required(data.get('sku'), "SKU")
        if not is_valid:
            return None, message
        
        is_valid, message = validate_sku(data['sku'])
        if not is_valid:
            return None, message
        
        if Product.query.filter_by(sku=data['sku']).first():
            return None, "SKU already exists"
        
        if data.get('barcode') and Product.query.filter_by(barcode=data['barcode']).first():
            return None, "Barcode already exists"
        
        # Auto-create unit from free text
        unit_id = ProductService.get_or_create_unit(data.get('unit'))
        
        product = Product(
            name=data['name'],
            sku=data['sku'],
            barcode=data.get('barcode'),
            description=data.get('description'),
            short_description=data.get('short_description'),
            category_id=data.get('category_id'),
            tags=data.get('tags'),
            brand=data.get('brand'),
            unit_id=unit_id,
            cost_price=data.get('cost_price', 0),
            selling_price=data.get('selling_price', 0),
            mrp=data.get('mrp', 0),
            wholesale_price=data.get('wholesale_price', 0),
            dealer_price=data.get('dealer_price', 0),
            tax_rate=data.get('tax_rate', 0),
            tax_inclusive=data.get('tax_inclusive', True),
            hsn_code=data.get('hsn_code'),
            discount_type=data.get('discount_type', 'none'),
            discount_value=data.get('discount_value', 0),
            track_inventory=data.get('track_inventory', True),
            reorder_level=data.get('reorder_level', 10),
            reorder_quantity=data.get('reorder_quantity', 50),
            weight=data.get('weight', 0),
            weight_unit=data.get('weight_unit', 'kg'),
            dimensions=data.get('dimensions'),
            is_active=data.get('is_active', True),
            is_featured=data.get('is_featured', False),
            expiry_date=data.get('expiry_date'),
            batch_number=data.get('batch_number'),
            created_by=created_by
        )
        
        db.session.add(product)
        db.session.commit()
        
        if product.track_inventory:
            default_warehouse = Warehouse.query.filter_by(is_primary=True).first()
            if not default_warehouse:
                default_warehouse = Warehouse.query.first()
            
            if default_warehouse:
                inventory = Inventory(
                    product_id=product.id,
                    warehouse_id=default_warehouse.id,
                    quantity=data.get('opening_stock', 0),
                    available_quantity=data.get('opening_stock', 0)
                )
                db.session.add(inventory)
                db.session.commit()
        
        return product, "Product created successfully"
    
    @staticmethod
    def update_product(product_id, data, updated_by=None):
        """Update a product"""
        product = Product.query.get(product_id)
        if not product:
            return None, "Product not found"
        
        # Auto-create unit from free text if provided
        if 'unit' in data:
            unit_id = ProductService.get_or_create_unit(data.get('unit'))
            product.unit_id = unit_id
        
        updatable_fields = [
            'name', 'barcode', 'description', 'short_description', 'category_id',
            'tags', 'brand', 'cost_price', 'selling_price', 'mrp',
            'wholesale_price', 'dealer_price', 'tax_rate', 'tax_inclusive',
            'hsn_code', 'discount_type', 'discount_value', 'track_inventory',
            'reorder_level', 'reorder_quantity', 'weight', 'weight_unit',
            'dimensions', 'is_active', 'is_featured', 'expiry_date', 'batch_number'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(product, field, data[field])
        
        if 'sku' in data and data['sku'] != product.sku:
            if Product.query.filter_by(sku=data['sku']).first():
                return None, "SKU already exists"
            product.sku = data['sku']
        
        product.updated_at = datetime.utcnow()
        db.session.commit()
        
        return product, "Product updated successfully"
    
    @staticmethod
    def delete_product(product_id):
        """Delete a product"""
        product = Product.query.get(product_id)
        if not product:
            return False, "Product not found"
        
        db.session.delete(product)
        db.session.commit()
        return True, "Product deleted successfully"
    
    @staticmethod
    def toggle_product_status(product_id):
        """Toggle product active status"""
        product = Product.query.get(product_id)
        if not product:
            return None, "Product not found"
        
        product.is_active = not product.is_active
        db.session.commit()
        
        status = "activated" if product.is_active else "deactivated"
        return product, f"Product {status}"
    
    @staticmethod
    def get_low_stock_products(warehouse_id=None):
        """Get products with low stock"""
        from sqlalchemy import text
        
        query = """
            SELECT p.* FROM products p
            JOIN inventory i ON p.id = i.product_id
            WHERE p.track_inventory = 1 AND p.is_active = 1
            AND i.quantity <= p.reorder_level
        """
        
        if warehouse_id:
            query += f" AND i.warehouse_id = {warehouse_id}"
        
        result = db.session.execute(text(query))
        product_ids = [row[0] for row in result]
        
        return Product.query.filter(Product.id.in_(product_ids)).all()
    
    @staticmethod
    def get_product_stats():
        """Get product statistics"""
        total = Product.query.count()
        active = Product.query.filter_by(is_active=True).count()
        inactive = Product.query.filter_by(is_active=False).count()
        low_stock = len(ProductService.get_low_stock_products())
        
        return {
            'total': total,
            'active': active,
            'inactive': inactive,
            'low_stock': low_stock
        }