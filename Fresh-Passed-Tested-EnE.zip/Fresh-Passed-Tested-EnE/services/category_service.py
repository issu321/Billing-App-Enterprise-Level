"""Category Management Service"""
from models import db
from models.product import Category


class CategoryService:
    """Service for category management"""
    
    @staticmethod
    def get_all_categories(parent_id=None, is_active=None, include_subcategories=False):
        """Get all categories with filters"""
        query = Category.query
        
        if parent_id is not None:
            query = query.filter(Category.parent_id == parent_id)
        
        if is_active is not None:
            query = query.filter(Category.is_active == is_active)
        
        categories = query.order_by(Category.sort_order, Category.name).all()
        
        if include_subcategories:
            result = []
            for cat in categories:
                cat_dict = cat.to_dict()
                cat_dict['subcategories'] = [sub.to_dict() for sub in cat.subcategories]
                result.append(cat_dict)
            return result
        
        return categories
    
    @staticmethod
    def get_category_by_id(category_id):
        """Get category by ID"""
        return Category.query.get(category_id)
    
    @staticmethod
    def create_category(data):
        """Create a new category"""
        if Category.query.filter_by(name=data['name'], parent_id=data.get('parent_id')).first():
            return None, "Category with this name already exists"
        
        category = Category(
            name=data['name'],
            code=data.get('code'),
            description=data.get('description'),
            parent_id=data.get('parent_id'),
            color=data.get('color', '#4F46E5'),
            icon=data.get('icon'),
            sort_order=data.get('sort_order', 0),
            is_active=data.get('is_active', True)
        )
        
        db.session.add(category)
        db.session.commit()
        
        return category, "Category created successfully"
    
    @staticmethod
    def update_category(category_id, data):
        """Update a category"""
        category = Category.query.get(category_id)
        if not category:
            return None, "Category not found"
        
        # Update fields
        if 'name' in data:
            existing = Category.query.filter_by(name=data['name'], parent_id=category.parent_id).first()
            if existing and existing.id != category_id:
                return None, "Category with this name already exists"
            category.name = data['name']
        
        if 'code' in data:
            category.code = data['code']
        if 'description' in data:
            category.description = data['description']
        if 'parent_id' in data:
            category.parent_id = data['parent_id']
        if 'color' in data:
            category.color = data['color']
        if 'icon' in data:
            category.icon = data['icon']
        if 'sort_order' in data:
            category.sort_order = data['sort_order']
        if 'is_active' in data:
            category.is_active = data['is_active']
        
        db.session.commit()
        return category, "Category updated successfully"
    
    @staticmethod
    def delete_category(category_id):
        """Delete a category"""
        category = Category.query.get(category_id)
        if not category:
            return False, "Category not found"
        
        if category.products:
            return False, "Cannot delete category with products. Move products first."
        
        db.session.delete(category)
        db.session.commit()
        return True, "Category deleted successfully"
    
    @staticmethod
    def get_category_tree():
        """Get category tree structure"""
        root_categories = Category.query.filter(Category.parent_id.is_(None), Category.is_active == True).all()
        
        def build_tree(category):
            node = category.to_dict()
            node['subcategories'] = [build_tree(sub) for sub in category.subcategories if sub.is_active]
            return node
        
        return [build_tree(cat) for cat in root_categories]
    
    @staticmethod
    def get_category_stats():
        """Get category statistics"""
        total = Category.query.count()
        active = Category.query.filter_by(is_active=True).count()
        
        return {
            'total': total,
            'active': active
        }
