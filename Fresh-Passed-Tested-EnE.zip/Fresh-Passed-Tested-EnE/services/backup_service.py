"""Backup and Restore Service"""
import os
import shutil
import sqlite3
import json
from datetime import datetime
from models import db
from flask import current_app


class BackupService:
    """Service for backup and restore operations"""
    
    @staticmethod
    def create_backup(backup_dir=None, include_uploads=True, include_logs=False):
        """Create database backup"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_name = f"backup_{timestamp}"
            
            if backup_dir is None:
                backup_dir = os.path.join(current_app.root_path, 'backups')
            
            os.makedirs(backup_dir, exist_ok=True)
            backup_path = os.path.join(backup_dir, backup_name)
            os.makedirs(backup_path, exist_ok=True)
            
            # Backup database
            db_path = current_app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
            if db_path.startswith('/'):
                db_file = db_path
            else:
                db_file = os.path.join(current_app.root_path, db_path)
            
            backup_db = os.path.join(backup_path, 'billing.db')
            
            # Use SQLite backup API
            source = sqlite3.connect(db_file)
            dest = sqlite3.connect(backup_db)
            with dest:
                source.backup(dest)
            dest.close()
            source.close()
            
            # Backup uploads
            if include_uploads:
                upload_dir = os.path.join(current_app.root_path, 'static', 'uploads')
                if os.path.exists(upload_dir):
                    backup_uploads = os.path.join(backup_path, 'uploads')
                    shutil.copytree(upload_dir, backup_uploads)
            
            # Create manifest
            manifest = {
                'backup_name': backup_name,
                'created_at': datetime.now().isoformat(),
                'database_file': 'billing.db',
                'app_version': current_app.config.get('APP_VERSION', '1.0.0'),
                'includes_uploads': include_uploads,
                'includes_logs': include_logs
            }
            
            manifest_path = os.path.join(backup_path, 'manifest.json')
            with open(manifest_path, 'w') as f:
                json.dump(manifest, f, indent=2)
            
            # Calculate size
            total_size = sum(os.path.getsize(os.path.join(dirpath, filename))
                           for dirpath, dirnames, filenames in os.walk(backup_path)
                           for filename in filenames)
            
            return {
                'success': True,
                'backup_name': backup_name,
                'backup_path': backup_path,
                'size': total_size,
                'created_at': manifest['created_at']
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def restore_backup(backup_path):
        """Restore from backup"""
        try:
            # Validate backup
            manifest_path = os.path.join(backup_path, 'manifest.json')
            if not os.path.exists(manifest_path):
                return {'success': False, 'error': 'Invalid backup: manifest not found'}
            
            with open(manifest_path) as f:
                manifest = json.load(f)
            
            # Restore database
            backup_db = os.path.join(backup_path, 'billing.db')
            if not os.path.exists(backup_db):
                return {'success': False, 'error': 'Database backup not found'}
            
            db_path = current_app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
            if not db_path.startswith('/'):
                db_file = os.path.join(current_app.root_path, db_path)
            else:
                db_file = db_path
            
            # Close current connections
            db.session.remove()
            
            # Backup current DB before restoring
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            current_backup = f"{db_file}.pre_restore_{timestamp}"
            shutil.copy2(db_file, current_backup)
            
            # Restore
            shutil.copy2(backup_db, db_file)
            
            # Restore uploads if included
            if manifest.get('includes_uploads'):
                backup_uploads = os.path.join(backup_path, 'uploads')
                if os.path.exists(backup_uploads):
                    upload_dir = os.path.join(current_app.root_path, 'static', 'uploads')
                    if os.path.exists(upload_dir):
                        shutil.rmtree(upload_dir)
                    shutil.copytree(backup_uploads, upload_dir)
            
            return {
                'success': True,
                'restored_from': manifest.get('backup_name'),
                'restored_at': datetime.now().isoformat()
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def list_backups(backup_dir=None):
        """List all available backups"""
        if backup_dir is None:
            backup_dir = os.path.join(current_app.root_path, 'backups')
        
        if not os.path.exists(backup_dir):
            return []
        
        backups = []
        for item in os.listdir(backup_dir):
            item_path = os.path.join(backup_dir, item)
            if os.path.isdir(item_path):
                manifest_path = os.path.join(item_path, 'manifest.json')
                if os.path.exists(manifest_path):
                    with open(manifest_path) as f:
                        manifest = json.load(f)
                    
                    # Calculate size
                    total_size = sum(os.path.getsize(os.path.join(dirpath, filename))
                                   for dirpath, dirnames, filenames in os.walk(item_path)
                                   for filename in filenames)
                    
                    backups.append({
                        'name': item,
                        'created_at': manifest.get('created_at'),
                        'size': total_size,
                        'path': item_path
                    })
        
        return sorted(backups, key=lambda x: x['created_at'], reverse=True)
    
    @staticmethod
    def delete_backup(backup_name, backup_dir=None):
        """Delete a backup"""
        try:
            if backup_dir is None:
                backup_dir = os.path.join(current_app.root_path, 'backups')
            
            backup_path = os.path.join(backup_dir, backup_name)
            if os.path.exists(backup_path):
                shutil.rmtree(backup_path)
                return {'success': True, 'message': 'Backup deleted'}
            
            return {'success': False, 'error': 'Backup not found'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    @staticmethod
    def export_data_json():
        """Export all data as JSON"""
        try:
            data = {}
            
            # Export each table
            from models.user import User, Role, Permission
            from models.product import Product, Category
            from models.customer import Customer, CustomerGroup
            from models.supplier import Supplier
            from models.sale import Sale, SaleItem
            from models.purchase import Purchase, PurchaseItem
            from models.inventory import Inventory, Warehouse
            from models.payment import Payment, Account
            from models.settings import BusinessSettings
            
            data['users'] = [u.to_dict() for u in User.query.all()]
            data['roles'] = [r.to_dict() for r in Role.query.all()]
            data['categories'] = [c.to_dict() for c in Category.query.all()]
            data['products'] = [p.to_dict() for p in Product.query.all()]
            data['customers'] = [c.to_dict() for c in Customer.query.all()]
            data['suppliers'] = [s.to_dict() for s in Supplier.query.all()]
            data['warehouses'] = [w.to_dict() for w in Warehouse.query.all()]
            data['sales'] = [s.to_dict() for s in Sale.query.all()]
            data['purchases'] = [p.to_dict() for p in Purchase.query.all()]
            
            return {
                'success': True,
                'data': data,
                'exported_at': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def get_database_stats():
        """Get database statistics"""
        try:
            db_path = current_app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
            if not db_path.startswith('/'):
                db_file = os.path.join(current_app.root_path, db_path)
            else:
                db_file = db_path
            
            file_size = os.path.getsize(db_file)
            
            # Get table counts
            from models.user import User
            from models.product import Product, Category
            from models.customer import Customer
            from models.supplier import Supplier
            from models.sale import Sale
            from models.purchase import Purchase
            from models.inventory import Inventory, Warehouse
            from models.audit_log import AuditLog
            
            stats = {
                'file_size': file_size,
                'file_size_formatted': f"{file_size / (1024*1024):.2f} MB",
                'tables': {
                    'users': User.query.count(),
                    'products': Product.query.count(),
                    'categories': Category.query.count(),
                    'customers': Customer.query.count(),
                    'suppliers': Supplier.query.count(),
                    'sales': Sale.query.count(),
                    'purchases': Purchase.query.count(),
                    'inventory': Inventory.query.count(),
                    'warehouses': Warehouse.query.count(),
                    'audit_logs': AuditLog.query.count()
                }
            }
            
            return stats
        except Exception as e:
            return {'error': str(e)}
