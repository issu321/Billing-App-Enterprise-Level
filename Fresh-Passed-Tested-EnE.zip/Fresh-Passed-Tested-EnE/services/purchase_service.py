"""Purchase Management Service"""
from models import db
from models.purchase import Purchase, PurchaseItem
from models.product import Product
from models.inventory import Inventory, InventoryTransaction, Warehouse
from models.supplier import SupplierLedger
from utils.helpers import generate_code
from datetime import datetime


class PurchaseService:
    """Service for purchase management"""
    
    @staticmethod
    def get_all_purchases(page=1, per_page=20, search=None, supplier_id=None, status=None, date_from=None, date_to=None):
        """Get all purchases with filters"""
        query = Purchase.query
        
        if search:
            query = query.filter(
                db.or_(
                    Purchase.purchase_number.ilike(f'%{search}%'),
                    Purchase.reference_number.ilike(f'%{search}%'),
                    Purchase.supplier_name.ilike(f'%{search}%')
                )
            )
        
        if supplier_id:
            query = query.filter(Purchase.supplier_id == supplier_id)
        if status:
            query = query.filter(Purchase.status == status)
        if date_from:
            query = query.filter(Purchase.purchase_date >= date_from)
        if date_to:
            query = query.filter(Purchase.purchase_date <= date_to)
        
        return query.order_by(Purchase.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    
    @staticmethod
    def get_purchase_by_id(purchase_id):
        """Get purchase by ID"""
        return Purchase.query.get(purchase_id)
    
    @staticmethod
    def create_purchase(data, created_by=None):
        """Create a new purchase"""
        # Generate purchase number
        last = Purchase.query.order_by(Purchase.id.desc()).first()
        last_number = last.id if last else 0
        purchase_number = generate_code('PO')
        
        purchase = Purchase(
            purchase_number=purchase_number,
            reference_number=data.get('reference_number'),
            purchase_date=data.get('purchase_date', datetime.utcnow()),
            due_date=data.get('due_date'),
            expected_date=data.get('expected_date'),
            
            supplier_id=data['supplier_id'],
            supplier_name=data.get('supplier_name'),
            supplier_address=data.get('supplier_address'),
            supplier_gst=data.get('supplier_gst'),
            
            discount_type=data.get('discount_type', 'none'),
            discount_value=data.get('discount_value', 0),
            tax_type=data.get('tax_type', 'exclusive'),
            tax_rate=data.get('tax_rate', 0),
            
            payment_terms=data.get('payment_terms'),
            
            warehouse_id=data.get('warehouse_id'),
            delivery_method=data.get('delivery_method'),
            
            notes=data.get('notes'),
            internal_notes=data.get('internal_notes'),
            
            status='draft',
            created_by=created_by
        )
        
        db.session.add(purchase)
        db.session.flush()
        
        # Add items
        items_data = data.get('items', [])
        for item_data in items_data:
            product = Product.query.get(item_data['product_id'])
            if not product:
                db.session.rollback()
                return None, f"Product not found: {item_data.get('product_id')}"
            
            quantity = float(item_data['quantity'])
            unit_price = float(item_data.get('unit_price', product.cost_price or 0))
            
            item_subtotal = quantity * unit_price
            
            # Tax
            tax_rate = float(item_data.get('tax_rate', 0))
            tax_amount = item_subtotal * (tax_rate / 100)
            
            purchase_item = PurchaseItem(
                purchase_id=purchase.id,
                product_id=product.id,
                product_name=product.name,
                product_sku=product.sku,
                quantity=quantity,
                unit=item_data.get('unit'),
                unit_price=unit_price,
                mrp=item_data.get('mrp', 0),
                selling_price=item_data.get('selling_price', 0),
                tax_rate=tax_rate,
                tax_amount=tax_amount,
                hsn_code=item_data.get('hsn_code', product.hsn_code),
                total_price=item_subtotal + tax_amount,
                batch_number=item_data.get('batch_number'),
                expiry_date=item_data.get('expiry_date'),
                manufacturing_date=item_data.get('manufacturing_date')
            )
            
            db.session.add(purchase_item)
        
        # Calculate totals
        subtotal = sum(float(item.total_price) for item in purchase.items)
        purchase.subtotal = subtotal
        
        # Discount
        discount = 0
        if purchase.discount_type == 'percentage' and purchase.discount_value:
            discount = subtotal * (float(purchase.discount_value) / 100)
        elif purchase.discount_type == 'fixed' and purchase.discount_value:
            discount = float(purchase.discount_value)
        purchase.discount_amount = discount
        
        # Tax
        if purchase.tax_type == 'exclusive':
            purchase.total_amount = subtotal - discount + float(purchase.shipping_amount or 0) + float(purchase.other_charges or 0) + float(purchase.round_off or 0)
        else:
            purchase.total_amount = subtotal - discount + float(purchase.shipping_amount or 0) + float(purchase.other_charges or 0) + float(purchase.round_off or 0)
        
        db.session.commit()
        
        return purchase, "Purchase created successfully"
    
    @staticmethod
    def receive_purchase(purchase_id, received_items, created_by=None):
        """Receive purchase items and update inventory"""
        purchase = Purchase.query.get(purchase_id)
        if not purchase:
            return None, "Purchase not found"
        
        for item_data in received_items:
            item = PurchaseItem.query.get(item_data['item_id'])
            if not item or item.purchase_id != purchase.id:
                continue
            
            received_qty = float(item_data.get('received_quantity', 0))
            item.received_quantity = float(item.received_quantity or 0) + received_qty
            
            if item.received_quantity >= item.quantity:
                item.status = 'received'
            elif item.received_quantity > 0:
                item.status = 'partial'
            
            # Update inventory
            warehouse_id = purchase.warehouse_id
            if not warehouse_id:
                default_wh = Warehouse.query.filter_by(is_primary=True).first()
                warehouse_id = default_wh.id if default_wh else None
            
            if warehouse_id:
                inventory = Inventory.query.filter_by(
                    product_id=item.product_id,
                    warehouse_id=warehouse_id
                ).first()
                
                if inventory:
                    inventory.quantity = float(inventory.quantity) + received_qty
                    inventory.available_quantity = float(inventory.available_quantity) + received_qty
                else:
                    inventory = Inventory(
                        product_id=item.product_id,
                        warehouse_id=warehouse_id,
                        quantity=received_qty,
                        available_quantity=received_qty
                    )
                    db.session.add(inventory)
                
                # Create inventory transaction
                inv_transaction = InventoryTransaction(
                    product_id=item.product_id,
                    warehouse_id=warehouse_id,
                    transaction_type='purchase',
                    quantity=received_qty,
                    unit_cost=item.unit_price,
                    total_cost=float(item.unit_price) * received_qty,
                    reference_type='purchase',
                    reference_id=purchase.id,
                    reference_number=purchase.purchase_number,
                    batch_number=item.batch_number,
                    expiry_date=item.expiry_date,
                    manufacturing_date=item.manufacturing_date,
                    created_by=created_by
                )
                db.session.add(inv_transaction)
        
        # Update purchase status
        all_received = all(item.status == 'received' for item in purchase.items)
        any_received = any(item.status in ('partial', 'received') for item in purchase.items)
        
        if all_received:
            purchase.status = 'received'
        elif any_received:
            purchase.status = 'partial'
        
        db.session.commit()
        return purchase, "Purchase received successfully"
    
    @staticmethod
    def get_purchase_stats(period='today'):
        """Get purchase statistics"""
        from utils.helpers import get_date_range
        from sqlalchemy import func
        
        start_date, end_date = get_date_range(period)
        
        total_purchases = Purchase.query.filter(Purchase.created_at.between(start_date, end_date)).count()
        total_amount = db.session.query(func.sum(Purchase.total_amount)).filter(
            Purchase.created_at.between(start_date, end_date)
        ).scalar() or 0
        
        return {
            'total_purchases': total_purchases,
            'total_amount': float(total_amount)
        }
