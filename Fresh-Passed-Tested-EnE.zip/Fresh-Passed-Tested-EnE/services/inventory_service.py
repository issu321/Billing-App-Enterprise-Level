"""Inventory Management Service"""
from models import db
from models.inventory import Inventory, InventoryTransaction, Warehouse, StockAdjustment
from models.product import Product
from utils.helpers import generate_code
from datetime import datetime


class InventoryService:
    """Service for inventory management"""
    
    @staticmethod
    def get_all_inventory(page=1, per_page=20, warehouse_id=None, product_id=None, low_stock_only=False):
        """Get all inventory records with filters"""
        query = Inventory.query.join(Product)
        
        if warehouse_id:
            query = query.filter(Inventory.warehouse_id == warehouse_id)
        
        if product_id:
            query = query.filter(Inventory.product_id == product_id)
        
        if low_stock_only:
            query = query.filter(Inventory.quantity <= Product.reorder_level)
        
        return query.order_by(Inventory.updated_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    
    @staticmethod
    def get_warehouse_by_id(warehouse_id):
        """Get warehouse by ID"""
        return Warehouse.query.get(warehouse_id)
    
    @staticmethod
    def get_all_warehouses(is_active=None):
        """Get all warehouses"""
        query = Warehouse.query
        if is_active is not None:
            query = query.filter(Warehouse.is_active == is_active)
        return query.order_by(Warehouse.name).all()
    
    @staticmethod
    def create_warehouse(data):
        """Create a new warehouse"""
        if Warehouse.query.filter_by(code=data['code']).first():
            return None, "Warehouse code already exists"
        
        warehouse = Warehouse(
            name=data['name'],
            code=data['code'],
            address=data.get('address'),
            city=data.get('city'),
            state=data.get('state'),
            country=data.get('country'),
            postal_code=data.get('postal_code'),
            phone=data.get('phone'),
            email=data.get('email'),
            manager_name=data.get('manager_name'),
            is_primary=data.get('is_primary', False),
            notes=data.get('notes')
        )
        
        db.session.add(warehouse)
        db.session.commit()
        
        return warehouse, "Warehouse created successfully"
    
    @staticmethod
    def update_warehouse(warehouse_id, data):
        """Update warehouse"""
        warehouse = Warehouse.query.get(warehouse_id)
        if not warehouse:
            return None, "Warehouse not found"
        
        for field in ['name', 'address', 'city', 'state', 'country', 'postal_code',
                      'phone', 'email', 'manager_name', 'is_primary', 'is_active', 'notes']:
            if field in data:
                setattr(warehouse, field, data[field])
        
        db.session.commit()
        return warehouse, "Warehouse updated successfully"
    
    @staticmethod
    def delete_warehouse(warehouse_id):
        """Delete warehouse"""
        warehouse = Warehouse.query.get(warehouse_id)
        if not warehouse:
            return False, "Warehouse not found"
        
        if warehouse.is_primary:
            return False, "Cannot delete primary warehouse"
        
        db.session.delete(warehouse)
        db.session.commit()
        return True, "Warehouse deleted successfully"
    
    @staticmethod
    def adjust_stock(data, created_by=None):
        """Create stock adjustment"""
        product = Product.query.get(data['product_id'])
        warehouse = Warehouse.query.get(data['warehouse_id'])
        
        if not product:
            return None, "Product not found"
        if not warehouse:
            return None, "Warehouse not found"
        
        # Get current inventory
        inventory = Inventory.query.filter_by(
            product_id=data['product_id'],
            warehouse_id=data['warehouse_id']
        ).first()
        
        if not inventory:
            return None, "Inventory record not found"
        
        quantity_before = float(inventory.quantity)
        quantity_after = data['quantity_after']
        difference = quantity_after - quantity_before
        
        # Create adjustment
        adjustment = StockAdjustment(
            adjustment_number=generate_code('ADJ'),
            product_id=data['product_id'],
            warehouse_id=data['warehouse_id'],
            adjustment_type=data.get('adjustment_type', 'system'),
            quantity_before=quantity_before,
            quantity_after=quantity_after,
            difference=difference,
            unit_cost=product.cost_price,
            total_cost_impact=difference * float(product.cost_price) if product.cost_price else 0,
            reason=data.get('reason', 'Stock adjustment'),
            notes=data.get('notes'),
            status='approved',
            created_by=created_by
        )
        
        # Update inventory
        inventory.quantity = quantity_after
        inventory.available_quantity = quantity_after - float(inventory.reserved_quantity or 0)
        
        # Create transaction record
        transaction = InventoryTransaction(
            product_id=data['product_id'],
            warehouse_id=data['warehouse_id'],
            transaction_type='adjustment',
            quantity=difference,
            unit_cost=product.cost_price,
            total_cost=difference * float(product.cost_price) if product.cost_price else 0,
            reference_type='adjustment',
            reference_number=adjustment.adjustment_number,
            balance_after=quantity_after,
            notes=data.get('reason'),
            created_by=created_by
        )
        
        db.session.add(adjustment)
        db.session.add(transaction)
        db.session.commit()
        
        return adjustment, "Stock adjusted successfully"
    
    @staticmethod
    def get_stock_adjustments(page=1, per_page=20, warehouse_id=None, product_id=None):
        """Get stock adjustments"""
        query = StockAdjustment.query
        
        if warehouse_id:
            query = query.filter(StockAdjustment.warehouse_id == warehouse_id)
        if product_id:
            query = query.filter(StockAdjustment.product_id == product_id)
        
        return query.order_by(StockAdjustment.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    
    @staticmethod
    def get_inventory_transactions(page=1, per_page=20, product_id=None, warehouse_id=None, transaction_type=None):
        """Get inventory transactions"""
        query = InventoryTransaction.query
        
        if product_id:
            query = query.filter(InventoryTransaction.product_id == product_id)
        if warehouse_id:
            query = query.filter(InventoryTransaction.warehouse_id == warehouse_id)
        if transaction_type:
            query = query.filter(InventoryTransaction.transaction_type == transaction_type)
        
        return query.order_by(InventoryTransaction.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    
    @staticmethod
    def get_inventory_stats():
        """Get inventory statistics"""
        from sqlalchemy import func
        
        total_products = Product.query.filter_by(is_active=True).count()
        
        total_stock = db.session.query(func.sum(Inventory.quantity)).scalar() or 0
        total_value = db.session.query(
            func.sum(Inventory.quantity * Product.cost_price)
        ).join(Product).scalar() or 0
        
        low_stock_count = db.session.query(Inventory).join(Product).filter(
            Inventory.quantity <= Product.reorder_level
        ).count()
        
        warehouse_count = Warehouse.query.filter_by(is_active=True).count()
        
        return {
            'total_products': total_products,
            'total_stock': float(total_stock),
            'total_value': float(total_value),
            'low_stock_count': low_stock_count,
            'warehouse_count': warehouse_count
        }
    
    @staticmethod
    def transfer_stock(data, created_by=None):
        """Transfer stock between warehouses"""
        from_warehouse = Warehouse.query.get(data['from_warehouse_id'])
        to_warehouse = Warehouse.query.get(data['to_warehouse_id'])
        product = Product.query.get(data['product_id'])
        
        if not from_warehouse or not to_warehouse:
            return None, "Warehouse not found"
        if not product:
            return None, "Product not found"
        
        quantity = data['quantity']
        
        # Check source inventory
        source_inv = Inventory.query.filter_by(
            product_id=product.id,
            warehouse_id=from_warehouse.id
        ).first()
        
        if not source_inv or float(source_inv.available_quantity) < quantity:
            return None, "Insufficient stock in source warehouse"
        
        # Deduct from source
        source_inv.quantity = float(source_inv.quantity) - quantity
        source_inv.available_quantity = float(source_inv.available_quantity) - quantity
        
        # Add to destination
        dest_inv = Inventory.query.filter_by(
            product_id=product.id,
            warehouse_id=to_warehouse.id
        ).first()
        
        if dest_inv:
            dest_inv.quantity = float(dest_inv.quantity) + quantity
            dest_inv.available_quantity = float(dest_inv.available_quantity) + quantity
        else:
            dest_inv = Inventory(
                product_id=product.id,
                warehouse_id=to_warehouse.id,
                quantity=quantity,
                available_quantity=quantity
            )
            db.session.add(dest_inv)
        
        # Create transactions
        out_transaction = InventoryTransaction(
            product_id=product.id,
            warehouse_id=from_warehouse.id,
            transaction_type='transfer_out',
            quantity=-quantity,
            unit_cost=product.cost_price,
            reference_type='transfer',
            reference_number=data.get('reference_number'),
            notes=f"Transferred to {to_warehouse.name}",
            created_by=created_by
        )
        
        in_transaction = InventoryTransaction(
            product_id=product.id,
            warehouse_id=to_warehouse.id,
            transaction_type='transfer_in',
            quantity=quantity,
            unit_cost=product.cost_price,
            reference_type='transfer',
            reference_number=data.get('reference_number'),
            notes=f"Transferred from {from_warehouse.name}",
            created_by=created_by
        )
        
        db.session.add(out_transaction)
        db.session.add(in_transaction)
        db.session.commit()
        
        return {'from_warehouse': from_warehouse.name, 'to_warehouse': to_warehouse.name}, "Stock transferred successfully"
