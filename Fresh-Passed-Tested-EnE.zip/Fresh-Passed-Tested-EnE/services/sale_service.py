"""Sale and POS Service"""
from models import db
from models.sale import Sale, SaleItem
from models.product import Product
from models.inventory import Inventory, Warehouse
from models.customer import Customer, CustomerLedger
from models.audit_log import AuditLog
from utils.helpers import generate_invoice_number
from datetime import datetime


class SaleService:
    """Service for sale and POS operations"""
    
    @staticmethod
    def get_all_sales(page=1, per_page=20, search=None, customer_id=None, 
                      payment_status=None, status=None, date_from=None, date_to=None,
                      is_pos_sale=None):
        """Get all sales with filters"""
        query = Sale.query
        
        if search:
            query = query.filter(
                db.or_(
                    Sale.invoice_number.ilike(f'%{search}%'),
                    Sale.customer_name.ilike(f'%{search}%')
                )
            )
        
        if customer_id:
            query = query.filter(Sale.customer_id == customer_id)
        if payment_status:
            query = query.filter(Sale.payment_status == payment_status)
        if status:
            query = query.filter(Sale.status == status)
        if date_from:
            query = query.filter(Sale.invoice_date >= date_from)
        if date_to:
            query = query.filter(Sale.invoice_date <= date_to)
        if is_pos_sale is not None:
            query = query.filter(Sale.is_pos_sale == is_pos_sale)
        
        return query.order_by(Sale.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    
    @staticmethod
    def get_sale_by_id(sale_id):
        """Get sale by ID"""
        return Sale.query.get(sale_id)
    
    @staticmethod
    def create_sale(data, created_by=None):
        """Create a new sale"""
        # Generate invoice number
        last_sale = Sale.query.order_by(Sale.id.desc()).first()
        last_number = last_sale.id if last_sale else 0
        invoice_number = generate_invoice_number(
            data.get('invoice_prefix', 'INV'),
            last_number
        )
        
        # Create sale
        sale = Sale(
            invoice_number=invoice_number,
            invoice_prefix=data.get('invoice_prefix', 'INV'),
            invoice_date=data.get('invoice_date', datetime.utcnow()),
            due_date=data.get('due_date'),
            
            # Customer info
            customer_id=data.get('customer_id'),
            customer_name=data.get('customer_name', 'Walk-in Customer'),
            customer_phone=data.get('customer_phone'),
            customer_email=data.get('customer_email'),
            customer_address=data.get('customer_address'),
            customer_gst=data.get('customer_gst'),
            
            # Pricing
            subtotal=0,
            tax_amount=0,
            discount_amount=0,
            shipping_amount=data.get('shipping_amount', 0),
            round_off=data.get('round_off', 0),
            total_amount=0,
            paid_amount=data.get('paid_amount', 0),
            
            # Discount & Tax
            discount_type=data.get('discount_type', 'none'),
            discount_value=data.get('discount_value', 0),
            tax_type=data.get('tax_type', 'inclusive'),
            tax_rate=data.get('tax_rate', 0),
            
            # Payment
            payment_method=data.get('payment_method', 'cash'),
            payment_status='pending',
            payment_reference=data.get('payment_reference'),
            
            # POS
            is_pos_sale=data.get('is_pos_sale', False),
            pos_session_id=data.get('pos_session_id'),
            counter_number=data.get('counter_number'),
            cashier_id=data.get('cashier_id'),
            
            status='confirmed',
            notes=data.get('notes'),
            internal_notes=data.get('internal_notes'),
            
            created_by=created_by
        )
        
        db.session.add(sale)
        db.session.flush()  # Get sale ID without committing
        
        # Add items
        items_data = data.get('items', [])
        for item_data in items_data:
            product = Product.query.get(item_data['product_id'])
            if not product:
                db.session.rollback()
                return None, f"Product not found: {item_data.get('product_id')}"
            
            quantity = float(item_data['quantity'])
            unit_price = float(item_data.get('unit_price', product.selling_price))
            
            # Calculate item totals
            item_subtotal = quantity * unit_price
            
            # Item discount
            item_discount = 0
            if item_data.get('discount_percent'):
                item_discount = item_subtotal * (float(item_data['discount_percent']) / 100)
            
            # Item tax
            item_tax = 0
            if item_data.get('tax_rate'):
                if sale.tax_type == 'exclusive':
                    item_tax = (item_subtotal - item_discount) * (float(item_data['tax_rate']) / 100)
            
            item_total = item_subtotal - item_discount + item_tax
            
            sale_item = SaleItem(
                sale_id=sale.id,
                product_id=product.id,
                product_name=product.name,
                product_sku=product.sku,
                product_barcode=product.barcode,
                variant_id=item_data.get('variant_id'),
                variant_name=item_data.get('variant_name'),
                quantity=quantity,
                unit_price=unit_price,
                cost_price=product.cost_price,
                mrp=product.mrp,
                discount_percent=item_data.get('discount_percent', 0),
                discount_amount=item_discount,
                tax_rate=item_data.get('tax_rate', product.tax_rate),
                tax_amount=item_tax,
                hsn_code=product.hsn_code,
                total_price=item_total,
                warehouse_id=item_data.get('warehouse_id')
            )
            
            db.session.add(sale_item)
            
            # Update inventory if tracking enabled
            if product.track_inventory:
                warehouse_id = item_data.get('warehouse_id')
                if not warehouse_id:
                    default_warehouse = Warehouse.query.filter_by(is_primary=True).first()
                    warehouse_id = default_warehouse.id if default_warehouse else None
                
                if warehouse_id:
                    inventory = Inventory.query.filter_by(
                        product_id=product.id,
                        warehouse_id=warehouse_id
                    ).first()
                    
                    if inventory:
                        inventory.quantity = float(inventory.quantity) - quantity
                        inventory.available_quantity = float(inventory.available_quantity) - quantity
                    
                    # Create inventory transaction
                    from models.inventory import InventoryTransaction
                    inv_transaction = InventoryTransaction(
                        product_id=product.id,
                        warehouse_id=warehouse_id,
                        transaction_type='sale',
                        quantity=-quantity,
                        unit_cost=product.cost_price,
                        total_cost=float(product.cost_price) * quantity if product.cost_price else 0,
                        reference_type='sale',
                        reference_id=sale.id,
                        reference_number=sale.invoice_number,
                        created_by=created_by
                    )
                    db.session.add(inv_transaction)
        
        # Calculate sale totals
        sale.calculate_totals()
        
        # Update payment status
        if sale.paid_amount and sale.paid_amount >= sale.total_amount:
            sale.payment_status = 'paid'
        elif sale.paid_amount and sale.paid_amount > 0:
            sale.payment_status = 'partial'
        
        db.session.commit()
        
        # Update customer ledger if customer exists
        if sale.customer_id:
            from services.customer_service import CustomerService
            CustomerService.add_ledger_entry(
                customer_id=sale.customer_id,
                entry_type='sale',
                amount=sale.total_amount,
                reference_type='sale',
                reference_id=sale.id,
                reference_number=sale.invoice_number,
                description=f"Sale invoice #{sale.invoice_number}"
            )
        
        return sale, "Sale created successfully"
    
    @staticmethod
    def get_sale_stats(period='today'):
        """Get sale statistics for a period"""
        from utils.helpers import get_date_range
        from sqlalchemy import func
        
        start_date, end_date = get_date_range(period)
        
        query = Sale.query.filter(Sale.created_at.between(start_date, end_date))
        
        total_sales = query.count()
        total_amount = db.session.query(func.sum(Sale.total_amount)).filter(
            Sale.created_at.between(start_date, end_date)
        ).scalar() or 0
        
        total_paid = db.session.query(func.sum(Sale.paid_amount)).filter(
            Sale.created_at.between(start_date, end_date)
        ).scalar() or 0
        
        return {
            'total_sales': total_sales,
            'total_amount': float(total_amount),
            'total_paid': float(total_paid),
            'balance': float(total_amount) - float(total_paid)
        }
    
    @staticmethod
    def get_daily_sales(days=7):
        """Get daily sales for chart"""
        from sqlalchemy import func
        from datetime import timedelta
        
        result = []
        for i in range(days - 1, -1, -1):
            date = datetime.now() - timedelta(days=i)
            start = date.replace(hour=0, minute=0, second=0, microsecond=0)
            end = date.replace(hour=23, minute=59, second=59, microsecond=999999)
            
            count = Sale.query.filter(Sale.created_at.between(start, end)).count()
            amount = db.session.query(func.sum(Sale.total_amount)).filter(
                Sale.created_at.between(start, end)
            ).scalar() or 0
            
            result.append({
                'date': date.strftime('%Y-%m-%d'),
                'day': date.strftime('%a'),
                'count': count,
                'amount': float(amount)
            })
        
        return result
    
    @staticmethod
    def get_top_selling_products(limit=10):
        """Get top selling products"""
        from sqlalchemy import func
        
        results = db.session.query(
            SaleItem.product_id,
            SaleItem.product_name,
            func.sum(SaleItem.quantity).label('total_qty'),
            func.sum(SaleItem.total_price).label('total_revenue')
        ).group_by(SaleItem.product_id).order_by(func.sum(SaleItem.quantity).desc()).limit(limit).all()
        
        return [{
            'product_id': r.product_id,
            'product_name': r.product_name,
            'total_quantity': float(r.total_qty),
            'total_revenue': float(r.total_revenue)
        } for r in results]
