"""Barcode and QR Code Service"""
import barcode
from barcode.writer import ImageWriter
import qrcode
from io import BytesIO
import base64


class BarcodeService:
    """Service for barcode and QR code generation"""
    
    BARCODE_TYPES = {
        'code128': 'code128',
        'code39': 'code39',
        'ean13': 'ean13',
        'ean8': 'ean8',
        'upca': 'upca',
        'isbn13': 'isbn13',
        'isbn10': 'isbn10'
    }
    
    @staticmethod
    def generate_barcode(data, barcode_type='code128', options=None):
        """Generate barcode image as base64"""
        try:
            if barcode_type not in BarcodeService.BARCODE_TYPES:
                barcode_type = 'code128'
            
            code_class = barcode.get_barcode_class(barcode_type)
            
            # Default options
            default_options = {
                'write_text': True,
                'module_height': 15,
                'module_width': 0.5,
                'font_size': 10,
                'text_distance': 5,
                'quiet_zone': 6.5
            }
            
            if options:
                default_options.update(options)
            
            rv = BytesIO()
            code = code_class(str(data), writer=ImageWriter())
            code.write(rv, options=default_options)
            rv.seek(0)
            
            img_str = base64.b64encode(rv.read()).decode('utf-8')
            return {
                'success': True,
                'data': f"data:image/png;base64,{img_str}",
                'type': barcode_type,
                'value': str(data)
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def generate_qr_code(data, size=10, error_correction='H'):
        """Generate QR code image as base64"""
        try:
            error_levels = {
                'L': qrcode.constants.ERROR_CORRECT_L,
                'M': qrcode.constants.ERROR_CORRECT_M,
                'Q': qrcode.constants.ERROR_CORRECT_Q,
                'H': qrcode.constants.ERROR_CORRECT_H
            }
            
            qr = qrcode.QRCode(
                version=1,
                error_correction=error_levels.get(error_correction, qrcode.constants.ERROR_CORRECT_H),
                box_size=size,
                border=2,
            )
            qr.add_data(str(data))
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            
            buffer = BytesIO()
            img.save(buffer, format='PNG')
            img_str = base64.b64encode(buffer.getvalue()).decode('utf-8')
            
            return {
                'success': True,
                'data': f"data:image/png;base64,{img_str}",
                'value': str(data)
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def generate_upi_qr(upi_id, name=None, amount=None, transaction_note=None, merchant_code=None):
        """Generate UPI payment QR code"""
        try:
            upi_data = f"upi://pay?pa={upi_id}&cu=INR"
            
            if name:
                upi_data += f"&pn={name.replace(' ', '%20')}"
            if amount and float(amount) > 0:
                upi_data += f"&am={amount}"
            if transaction_note:
                upi_data += f"&tn={transaction_note.replace(' ', '%20')}"
            if merchant_code:
                upi_data += f"&mc={merchant_code}"
            
            return BarcodeService.generate_qr_code(upi_data, size=10)
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def generate_product_barcode(product):
        """Generate barcode for a product"""
        barcode_data = product.barcode or product.sku
        return BarcodeService.generate_barcode(barcode_data)
    
    @staticmethod
    def generate_product_qr(product):
        """Generate QR code with product info"""
        qr_data = f"""Product: {product.name}
SKU: {product.sku}
Price: {product.selling_price}
Barcode: {product.barcode or 'N/A'}"""
        return BarcodeService.generate_qr_code(qr_data, size=8)
    
    @staticmethod
    def generate_bulk_barcodes(products, barcode_type='code128'):
        """Generate barcodes for multiple products"""
        results = []
        for product in products:
            barcode_data = product.barcode or product.sku
            result = BarcodeService.generate_barcode(barcode_data, barcode_type)
            if result['success']:
                results.append({
                    'product_id': product.id,
                    'product_name': product.name,
                    'sku': product.sku,
                    'barcode_data': barcode_data,
                    'barcode_image': result['data']
                })
        return results
    
    @staticmethod
    def get_barcode_types():
        """Get available barcode types"""
        return [
            {'code': 'code128', 'name': 'Code 128', 'description': 'Most versatile, alphanumeric support'},
            {'code': 'code39', 'name': 'Code 39', 'description': 'Simple alphanumeric'},
            {'code': 'ean13', 'name': 'EAN-13', 'description': '13-digit retail barcode'},
            {'code': 'ean8', 'name': 'EAN-8', 'description': '8-digit short barcode'},
            {'code': 'upca', 'name': 'UPC-A', 'description': '12-digit US retail barcode'},
        ]
