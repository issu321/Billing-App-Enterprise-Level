#!/bin/sh

# ============================================================
#   Billing Installation App
#   By Mohammed Usman
# ============================================================

# --- Real Escape Character ---
ESC=$(printf '\033')
CR=$(printf "\r")

# --- Colors ---
C_RED="${ESC}[38;2;255;90;90m"
C_GRN="${ESC}[38;2;60;255;130m"
C_YLW="${ESC}[38;2;255;230;80m"
C_BLU="${ESC}[38;2;80;170;255m"
C_CYN="${ESC}[38;2;80;240;255m"
C_MAG="${ESC}[38;2;220;80;255m"
C_ORG="${ESC}[38;2;255;150;50m"
C_WHT="${ESC}[38;2;245;245;245m"
C_GRY="${ESC}[38;2;140;140;140m"
C_DRK="${ESC}[38;2;80;80;80m"
C_RST="${ESC}[0m"
C_BLD="${ESC}[1m"
C_DIM="${ESC}[2m"

# --- Cursor Control ---
HIDE="${ESC}[?25l"
SHOW="${ESC}[?25h"

# --- Print Helpers ---
ok()   { printf "  %s%s▶%s %s%s
" "$C_GRN" "$C_BLD" "$C_RST" "$C_WHT" "$1"; }
err()  { printf "  %s%s▶%s %s%s
" "$C_RED" "$C_BLD" "$C_RST" "$C_WHT" "$1"; }
info() { printf "  %s%s▶%s %s%s
" "$C_BLU" "$C_BLD" "$C_RST" "$C_WHT" "$1"; }
warn() { printf "  %s%s▶%s %s%s
" "$C_YLW" "$C_BLD" "$C_RST" "$C_WHT" "$1"; }

# --- Banner ---
banner() {
    printf "
"
    printf "%s" "$C_CYN"
    printf "      ____       _ _ _            _   _           _        _     
"
    printf "     |  _ \     | | (_)          | | (_)         | |      | |    
"
    printf "     | |_) | ___| | |_  __ _  ___| |_ _  ___ __ _| |_ __ _| |    
"
    printf "     |  _ < / _ \ | | |/ _\` |/ __| __| |/ __/ _\` | __/ _\` |    
"
    printf "     | |_) |  __/ | | | (_| | (__| |_| | (_| (_| | || (_| | |    
"
    printf "     |____/ \___|_|_|_|\__, |\___|\__|_|\___\__,_|\__\__,_|_|    
"
    printf "                        __/ |                                    
"
    printf "                       |___/                                     
"
    printf "%s" "$C_RST"
    printf "
"
    printf "  %s%s╔══════════════════════════════════════════════════════════════╗%s
" "$C_MAG" "$C_BLD" "$C_RST"
    printf "  %s%s║%s%s      Billing Installation App                             %s%s║%s
" "$C_MAG" "$C_BLD" "$C_RST" "$C_WHT" "$C_MAG" "$C_BLD" "$C_RST"
    printf "  %s%s║%s%s      By Mohammed Usman                                    %s%s║%s
" "$C_MAG" "$C_BLD" "$C_RST" "$C_CYN" "$C_MAG" "$C_BLD" "$C_RST"
    printf "  %s%s╚══════════════════════════════════════════════════════════════╝%s
" "$C_MAG" "$C_BLD" "$C_RST"
    printf "
"
}

# --- Section Header ---
section() {
    printf "
"
    printf "  %s%s╭──────────────────────────────────────────────────────────────╮%s
" "$C_BLU" "$C_BLD" "$C_RST"
    printf "  %s%s│%s  %s%s%s%s%s
" "$C_BLU" "$C_BLD" "$C_RST" "$C_YLW" "$C_BLD" "$1" "$C_RST" "$C_BLU" "$C_BLD" "$C_RST"
    printf "  %s%s╰──────────────────────────────────────────────────────────────╯%s
" "$C_BLU" "$C_BLD" "$C_RST"
}

# --- Wave Animation ---
wave() {
    chars="▁▂▃▄▅▆▇█▇▆▅▄▃▂"
    len=16
    printf "
"
    cycles=0
    while [ "$cycles" -lt 3 ]; do
        offset=$cycles
        printf "  %s" "$C_BLU"
        i=0
        while [ "$i" -lt 50 ]; do
            idx=$(( (i + offset) % len + 1 ))
            char=$(printf "%s" "$chars" | cut -c"$idx")
            printf "%s" "$char"
            i=$((i + 1))
        done
        printf "%s" "$C_RST"
        printf "%s" "$CR"
        sleep 0.06
        cycles=$((cycles + 1))
    done
    printf "${ESC}[2K%s
" "$CR"
}

# --- Scanner Animation ---
scanner() {
    pid="$1"
    msg="$2"
    scan="▏▎▍▌▋▊▉█▉▊▋▌▍▎▏"
    len=15
    idx=1
    while kill -0 "$pid" 2>/dev/null; do
        char=$(printf "%s" "$scan" | cut -c"$idx")
        printf "%s" "$CR"
        printf "  %s%s%s %s%s%s" "$C_CYN" "$char" "$C_RST" "$C_WHT" "$msg" "$C_RST"
        idx=$((idx + 1))
        if [ "$idx" -gt "$len" ]; then
            idx=1
        fi
        sleep 0.07
    done
    printf "%s" "$CR"
    printf "${ESC}[2K"
    printf "  %s%s%s %s%s%s
" "$C_GRN" "✓" "$C_RST" "$C_WHT" "$msg" "$C_RST"
}

# --- Dot Bounce ---
dot_bounce() {
    pid="$1"
    msg="$2"
    dots=".   ..  ... ..  .   "
    len=20
    idx=1
    while kill -0 "$pid" 2>/dev/null; do
        dot=$(printf "%s" "$dots" | cut -c"$idx"-$((idx+2)) )
        printf "%s" "$CR"
        printf "  %s%s%s%s" "$C_YLW" "$msg" "$dot" "$C_RST"
        idx=$((idx + 3))
        if [ "$idx" -gt "$len" ]; then
            idx=1
        fi
        sleep 0.2
    done
    printf "%s" "$CR"
    printf "${ESC}[2K"
    printf "  %s%s%s %s%s%s
" "$C_GRN" "✓" "$C_RST" "$C_WHT" "$msg" "$C_RST"
}

# --- Progress Bar ---
progress() {
    current="$1"
    total="$2"
    label="$3"
    if [ "$total" -eq 0 ]; then total=1; fi
    percent=$((current * 100 / total))
    bar_width=40
    filled=$((current * bar_width / total))
    empty=$((bar_width - filled))
    printf "%s" "$CR"
    printf "  %s[" "$C_DRK"
    i=0
    while [ "$i" -lt "$filled" ]; do
        pos=$((i * 255 / bar_width))
        if [ "$pos" -lt 128 ]; then
            r=$((pos * 2))
            g=$((100 + pos))
            b=$((255 - pos))
        else
            r=255
            g=$((200 + (pos - 128) * 55 / 127))
            b=0
        fi
        printf "${ESC}[38;2;%d;%d;%dm█" "$r" "$g" "$b"
        i=$((i + 1))
    done
    printf "%s" "$C_RST"
    i=0
    while [ "$i" -lt "$empty" ]; do
        printf "%s░" "$C_DIM"
        i=$((i + 1))
    done
    printf "%s] %s%3d%%%s %s%s%s" "$C_DRK" "$C_WHT" "$percent" "$C_RST" "$C_CYN" "$label" "$C_RST"
    if [ "$current" -eq "$total" ]; then
        printf "
"
    fi
}

# --- Typewriter ---
type() {
    text="$1"
    color="$2"
    printf "  %s" "$color"
    i=1
    len=$(printf "%s" "$text" | wc -c)
    while [ "$i" -le "$len" ]; do
        char=$(printf "%s" "$text" | cut -c"$i")
        printf "%s" "$char"
        sleep 0.02
        i=$((i + 1))
    done
    printf "%s
" "$C_RST"
}

# --- Status Box ---
box() {
    title="$1"
    line1="$2"
    line2="$3"
    color="$4"
    printf "
"
    printf "  %s%s┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓%s
" "$color" "$C_BLD" "$C_RST"
    printf "  %s%s┃%s  %s%s%s%s%s
" "$color" "$C_BLD" "$C_RST" "$color" "$C_BLD" "$title" "$C_RST" "$color" "$C_BLD" "$C_RST"
    printf "  %s%s┃%s  %s%s%s
" "$color" "$C_BLD" "$C_RST" "$C_WHT" "$line1" "$C_RST" "$color" "$C_BLD" "$C_RST"
    printf "  %s%s┃%s  %s%s%s
" "$color" "$C_BLD" "$C_RST" "$C_GRY" "$line2" "$C_RST" "$color" "$C_BLD" "$C_RST"
    printf "  %s%s┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛%s
" "$color" "$C_BLD" "$C_RST"
    printf "
"
}

# --- Pulsing Text ---
pulse() {
    text="$1"
    i=0
    while [ "$i" -lt 4 ]; do
        printf "%s" "$CR"
        printf "  %s%s%s%s" "$C_GRN" "$C_BLD" "$text" "$C_RST"
        sleep 0.15
        printf "%s" "$CR"
        printf "  %s%s%s%s" "$C_CYN" "$C_BLD" "$text" "$C_RST"
        sleep 0.15
        i=$((i + 1))
    done
    printf "%s" "$CR"
    printf "${ESC}[2K"
    printf "  %s%s%s%s
" "$C_GRN" "$C_BLD" "$text" "$C_RST"
}

# --- Command Check ---
has_cmd() {
    command -v "$1" >/dev/null 2>&1
}

# ============================================================
#   MAIN
# ============================================================

printf "%s" "$HIDE"
clear
banner
wave

section "STEP 1: Python Environment Check"

if has_cmd python3; then
    PYTHON_CMD="python3"
    PYTHON_VERSION=$(python3 --version 2>&1)
    pulse "Scanning system..."
    ok "Python detected: $PYTHON_VERSION"
elif has_cmd python; then
    PYTHON_CMD="python"
    PYTHON_VERSION=$(python --version 2>&1)
    pulse "Scanning system..."
    ok "Python detected: $PYTHON_VERSION"
else
    err "Python is not installed!"
    info "Run: sudo apt update && sudo apt install python3 python3-venv python3-pip -y"
    printf "
  %s%sPress Enter to exit...%s" "$C_YLW" "$C_BLD" "$C_RST"
    printf "%s" "$SHOW"
    read -r dummy
    exit 1
fi

section "STEP 2: Package Manager Check"

if has_cmd pip3; then
    PIP_CMD="pip3"
    ok "pip3 found on system"
elif has_cmd pip; then
    PIP_CMD="pip"
    ok "pip found on system"
else
    warn "pip not found. Auto-installing..."
    $PYTHON_CMD -m ensurepip --upgrade >/dev/null 2>&1 &
    scanner $! "Installing pip"
    wait $!
    if [ $? -ne 0 ]; then
        err "Failed to install pip automatically"
        info "Install manually: sudo apt install python3-pip -y"
        printf "
  %s%sPress Enter to exit...%s" "$C_YLW" "$C_BLD" "$C_RST"
        printf "%s" "$SHOW"
        read -r dummy
        exit 1
    fi
    if has_cmd pip3; then
        PIP_CMD="pip3"
    else
        PIP_CMD="pip"
    fi
    ok "pip installed successfully"
fi

section "STEP 3: Upgrading pip"

type "Upgrading pip to latest version..." "$C_CYN"
$PYTHON_CMD -m pip install --upgrade pip >/dev/null 2>&1 &
scanner $! "Upgrading pip"
wait $!
if [ $? -eq 0 ]; then
    ok "pip upgraded to latest version"
else
    warn "pip upgrade had issues, continuing..."
fi

section "STEP 4: Virtual Environment Setup"

VENV_DIR="venv"

if [ -d "$VENV_DIR" ]; then
    info "Virtual environment exists at: $(pwd)/$VENV_DIR"
    ok "Using existing environment"
else
    type "Creating virtual environment..." "$C_CYN"
    $PYTHON_CMD -m venv "$VENV_DIR" >/dev/null 2>&1 &
    dot_bounce $! "Creating venv"
    wait $!
    if [ $? -eq 0 ]; then
        ok "Virtual environment created"
    else
        err "Failed to create virtual environment!"
        info "Install python3-venv: sudo apt install python3-venv -y"
        printf "
  %s%sPress Enter to exit...%s" "$C_YLW" "$C_BLD" "$C_RST"
        printf "%s" "$SHOW"
        read -r dummy
        exit 1
    fi
fi

box "✓ VIRTUAL ENVIRONMENT CONFIRMED" \
    "Location: $(pwd)/$VENV_DIR" \
    "Python:   $PYTHON_VERSION" \
    "$C_GRN"

section "STEP 5: Dependency Installation"

if [ -f "requirements.txt" ]; then
    info "Found requirements.txt"
    type "Installing packages, please wait..." "$C_CYN"
    TOTAL_PACKAGES=$(wc -l < requirements.txt | tr -d " ")
    if [ "$TOTAL_PACKAGES" -eq 0 ]; then
        TOTAL_PACKAGES=1
    fi
    if [ -f "$VENV_DIR/bin/activate" ]; then
        . "$VENV_DIR/bin/activate"
    elif [ -f "$VENV_DIR/Scripts/activate" ]; then
        . "$VENV_DIR/Scripts/activate"
    else
        err "Could not find venv activation script!"
        printf "
  %s%sPress Enter to exit...%s" "$C_YLW" "$C_BLD" "$C_RST"
        printf "%s" "$SHOW"
        read -r dummy
        exit 1
    fi
    pip install -r requirements.txt >/dev/null 2>&1 &
    PID=$!
    i=0
    while kill -0 "$PID" 2>/dev/null; do
        i=$((i + 1))
        if [ "$i" -gt "$TOTAL_PACKAGES" ]; then
            i="$TOTAL_PACKAGES"
        fi
        progress "$i" "$TOTAL_PACKAGES" "Installing dependencies..."
        sleep 0.35
    done
    wait "$PID"
    INSTALL_STATUS=$?
    if [ "$INSTALL_STATUS" -eq 0 ]; then
        progress "$TOTAL_PACKAGES" "$TOTAL_PACKAGES" "All packages installed!"
        ok "Dependencies installed successfully"
    else
        progress "$TOTAL_PACKAGES" "$TOTAL_PACKAGES" "Installation completed"
        warn "Some packages had warnings, continuing..."
    fi
    deactivate >/dev/null 2>&1 || true
else
    warn "No requirements.txt found"
    info "Skipping package installation"
fi

section "STEP 6: Launching Application"

if [ -f "app.py" ]; then
    info "Found app.py"
    printf "
"
    type "Starting Billing Application..." "$C_MAG"
    printf "
"
    printf "  %s%s━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━%s
" "$C_GRN" "$C_BLD" "$C_RST"
    printf "
"
    if [ -f "$VENV_DIR/bin/activate" ]; then
        . "$VENV_DIR/bin/activate"
    elif [ -f "$VENV_DIR/Scripts/activate" ]; then
        . "$VENV_DIR/Scripts/activate"
    fi
    printf "%s" "$SHOW"
    $PYTHON_CMD app.py
    APP_EXIT=$?
    printf "%s" "$HIDE"
    deactivate >/dev/null 2>&1 || true
    printf "
"
    printf "  %s%s━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━%s
" "$C_GRN" "$C_BLD" "$C_RST"
    printf "
"
    if [ "$APP_EXIT" -eq 0 ]; then
        ok "Application exited cleanly"
    else
        err "Application exited with code: $APP_EXIT"
    fi
else
    err "app.py not found in: $(pwd)"
    info "Ensure app.py is in the same directory as this script"
    printf "
  %s%sPress Enter to exit...%s" "$C_YLW" "$C_BLD" "$C_RST"
    printf "%s" "$SHOW"
    read -r dummy
    exit 1
fi

printf "
"
box "Thank you for using Billing Installation App!" \
    "By Mohammed Usman" \
    "Session completed successfully" \
    "$C_CYN"

printf "
  %s%sPress Enter to exit...%s" "$C_YLW" "$C_BLD" "$C_RST"
printf "%s" "$SHOW"
read -r dummy