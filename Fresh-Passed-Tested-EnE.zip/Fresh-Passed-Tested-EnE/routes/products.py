"""Product Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.product_service import ProductService
from services.category_service import CategoryService
from models.product import Product
from models import db

products_bp = Blueprint('products', __name__, template_folder='templates')


@products_bp.route('/')
@login_required
def index():
    """Product list"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    search = request.args.get('search', '')
    category_id = request.args.get('category_id', type=int)
    stock_status = request.args.get('stock_status')
    
    products = ProductService.get_all_products(
        page=page, per_page=per_page, search=search,
        category_id=category_id, stock_status=stock_status
    )
    categories = CategoryService.get_all_categories()
    stats = ProductService.get_product_stats()
    
    return render_template('products/index.html',
                         products=products,
                         categories=categories,
                         stats=stats,
                         search=search,
                         category_id=category_id)


@products_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Create product"""
    categories = CategoryService.get_all_categories()
    
    if request.method == 'POST':
        data = {
            'name': request.form.get('name'),
            'sku': request.form.get('sku'),
            'barcode': request.form.get('barcode'),
            'description': request.form.get('description'),
            'short_description': request.form.get('short_description'),
            'category_id': request.form.get('category_id', type=int),
            'brand': request.form.get('brand'),
            'tags': request.form.get('tags'),
            'unit': request.form.get('unit'),
            'cost_price': request.form.get('cost_price', type=float),
            'selling_price': request.form.get('selling_price', type=float),
            'mrp': request.form.get('mrp', type=float),
            'wholesale_price': request.form.get('wholesale_price', type=float),
            'dealer_price': request.form.get('dealer_price', type=float),
            'tax_rate': request.form.get('tax_rate', type=float),
            'hsn_code': request.form.get('hsn_code'),
            'discount_type': request.form.get('discount_type', 'none'),
            'discount_value': request.form.get('discount_value', type=float, default=0),
            'track_inventory': request.form.get('track_inventory') == 'on',
            'reorder_level': request.form.get('reorder_level', type=float, default=10),
            'reorder_quantity': request.form.get('reorder_quantity', type=float, default=50),
            'weight': request.form.get('weight', type=float),
            'dimensions': request.form.get('dimensions'),
            'is_active': request.form.get('is_active') != 'off',
            'opening_stock': request.form.get('opening_stock', type=float, default=0)
        }
        
        product, message = ProductService.create_product(data, created_by=current_user.id)
        
        if product:
            flash('Product created successfully!', 'success')
            return redirect(url_for('products.index'))
        else:
            flash(message, 'danger')
    
    return render_template('products/create.html', categories=categories)


@products_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    """Edit product"""
    product = ProductService.get_product_by_id(id)
    if not product:
        flash('Product not found.', 'danger')
        return redirect(url_for('products.index'))
    
    categories = CategoryService.get_all_categories()
    
    if request.method == 'POST':
        data = {
            'name': request.form.get('name'),
            'sku': request.form.get('sku'),
            'barcode': request.form.get('barcode'),
            'description': request.form.get('description'),
            'short_description': request.form.get('short_description'),
            'category_id': request.form.get('category_id', type=int),
            'brand': request.form.get('brand'),
            'tags': request.form.get('tags'),
            'unit': request.form.get('unit'),
            'cost_price': request.form.get('cost_price', type=float),
            'selling_price': request.form.get('selling_price', type=float),
            'mrp': request.form.get('mrp', type=float),
            'wholesale_price': request.form.get('wholesale_price', type=float),
            'dealer_price': request.form.get('dealer_price', type=float),
            'tax_rate': request.form.get('tax_rate', type=float),
            'hsn_code': request.form.get('hsn_code'),
            'discount_type': request.form.get('discount_type', 'none'),
            'discount_value': request.form.get('discount_value', type=float, default=0),
            'track_inventory': request.form.get('track_inventory') == 'on',
            'reorder_level': request.form.get('reorder_level', type=float, default=10),
            'reorder_quantity': request.form.get('reorder_quantity', type=float, default=50),
            'weight': request.form.get('weight', type=float),
            'dimensions': request.form.get('dimensions'),
            'is_active': request.form.get('is_active') == 'on'
        }
        
        product, message = ProductService.update_product(id, data, updated_by=current_user.id)
        
        if product:
            flash('Product updated successfully!', 'success')
            return redirect(url_for('products.index'))
        else:
            flash(message, 'danger')
    
    return render_template('products/edit.html', product=product, categories=categories)


@products_bp.route('/delete/<int:id>', methods=['POST'])
@login_required
def delete(id):
    """Delete product"""
    success, message = ProductService.delete_product(id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('products.index'))


@products_bp.route('/view/<int:id>')
@login_required
def view(id):
    """View product details"""
    product = ProductService.get_product_by_id(id)
    if not product:
        flash('Product not found.', 'danger')
        return redirect(url_for('products.index'))
    return render_template('products/view.html', product=product)


# API routes
@products_bp.route('/api/list')
@login_required
def api_list():
    """Get products as JSON"""
    search = request.args.get('search', '')
    category_id = request.args.get('category_id', type=int)
    
    products = ProductService.get_all_products(
        search=search, category_id=category_id, per_page=100
    )
    
    return jsonify({
        'success': True,
        'products': [p.to_dict() for p in products.items]
    })


@products_bp.route('/api/search')
@login_required
def api_search():
    """Search products for POS/autocomplete"""
    q = request.args.get('q', '')
    
    if len(q) < 2:
        return jsonify({'success': True, 'products': []})
    
    products = Product.query.filter(
        db.or_(
            Product.name.ilike(f'%{q}%'),
            Product.sku.ilike(f'%{q}%'),
            Product.barcode.ilike(f'%{q}%')
        ),
        Product.is_active == True
    ).limit(20).all()
    
    return jsonify({
        'success': True,
        'products': [p.to_dict() for p in products]
    })


@products_bp.route('/api/<int:id>')
@login_required
def api_get(id):
    """Get single product as JSON"""
    product = ProductService.get_product_by_id(id)
    if not product:
        return jsonify({'success': False, 'message': 'Product not found'}), 404
    return jsonify({'success': True, 'product': product.to_dict()})