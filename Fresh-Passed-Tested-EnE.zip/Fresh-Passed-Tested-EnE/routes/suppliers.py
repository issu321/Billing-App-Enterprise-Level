"""Supplier Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.supplier_service import SupplierService

suppliers_bp = Blueprint('suppliers', __name__, template_folder='templates')


@suppliers_bp.route('/')
@login_required
def index():
    """Supplier list"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    
    suppliers = SupplierService.get_all_suppliers(page=page, search=search)
    stats = SupplierService.get_supplier_stats()
    return render_template('suppliers/index.html', suppliers=suppliers, stats=stats, search=search)


@suppliers_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Create supplier"""
    if request.method == 'POST':
        data = {k: v for k, v in request.form.items() if v}
        data['credit_limit'] = request.form.get('credit_limit', type=float, default=0)
        data['credit_days'] = request.form.get('credit_days', type=int, default=0)
        data['lead_time_days'] = request.form.get('lead_time_days', type=int, default=0)
        
        supplier, message = SupplierService.create_supplier(data, created_by=current_user.id)
        if supplier:
            flash('Supplier created successfully!', 'success')
            return redirect(url_for('suppliers.index'))
        else:
            flash(message, 'danger')
    
    return render_template('suppliers/create.html')


@suppliers_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    """Edit supplier"""
    supplier = SupplierService.get_supplier_by_id(id)
    if not supplier:
        flash('Supplier not found.', 'danger')
        return redirect(url_for('suppliers.index'))
    
    if request.method == 'POST':
        data = {k: v for k, v in request.form.items() if v}
        data['credit_limit'] = request.form.get('credit_limit', type=float)
        data['credit_days'] = request.form.get('credit_days', type=int)
        data['is_active'] = request.form.get('is_active') == 'on'
        
        supplier, message = SupplierService.update_supplier(id, data)
        if supplier:
            flash('Supplier updated successfully!', 'success')
            return redirect(url_for('suppliers.index'))
        else:
            flash(message, 'danger')
    
    return render_template('suppliers/edit.html', supplier=supplier)


@suppliers_bp.route('/delete/<int:id>', methods=['POST'])
@login_required
def delete(id):
    """Delete supplier"""
    success, message = SupplierService.delete_supplier(id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('suppliers.index'))


@suppliers_bp.route('/view/<int:id>')
@login_required
def view(id):
    """View supplier"""
    supplier = SupplierService.get_supplier_by_id(id)
    if not supplier:
        flash('Supplier not found.', 'danger')
        return redirect(url_for('suppliers.index'))
    
    ledger = SupplierService.get_supplier_ledger(id)
    return render_template('suppliers/view.html', supplier=supplier, ledger=ledger)


@suppliers_bp.route('/api/search')
@login_required
def api_search():
    """Search suppliers"""
    q = request.args.get('q', '')
    if len(q) < 2:
        return jsonify({'success': True, 'suppliers': []})
    
    from models.supplier import Supplier
    from models import db
    suppliers = Supplier.query.filter(
        db.or_(
            Supplier.name.ilike(f'%{q}%'),
            Supplier.phone.ilike(f'%{q}%'),
            Supplier.supplier_code.ilike(f'%{q}%')
        ),
        Supplier.is_active == True
    ).limit(10).all()
    
    return jsonify({'success': True, 'suppliers': [s.to_dict() for s in suppliers]})
