"""Backup and Restore Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.backup_service import BackupService

backup_bp = Blueprint('backup', __name__, template_folder='templates')


@backup_bp.route('/')
@login_required
def index():
    """Backup management"""
    backups = BackupService.list_backups()
    stats = BackupService.get_database_stats()
    return render_template('backup/index.html', backups=backups, stats=stats)


@backup_bp.route('/create', methods=['POST'])
@login_required
def create():
    """Create backup"""
    include_uploads = request.form.get('include_uploads') == 'on'
    result = BackupService.create_backup(include_uploads=include_uploads)
    
    if result['success']:
        flash(f"Backup created successfully! Size: {result['size'] / (1024*1024):.2f} MB", 'success')
    else:
        flash(f"Backup failed: {result.get('error', 'Unknown error')}", 'danger')
    
    return redirect(url_for('backup.index'))


@backup_bp.route('/restore', methods=['POST'])
@login_required
def restore():
    """Restore from backup"""
    backup_name = request.form.get('backup_name')
    
    if not backup_name:
        flash('No backup selected.', 'danger')
        return redirect(url_for('backup.index'))
    
    import os
    backup_dir = os.path.join(__import__('flask').current_app.root_path, 'backups')
    backup_path = os.path.join(backup_dir, backup_name)
    
    result = BackupService.restore_backup(backup_path)
    
    if result['success']:
        flash('Backup restored successfully! Please restart the application.', 'success')
    else:
        flash(f"Restore failed: {result.get('error', 'Unknown error')}", 'danger')
    
    return redirect(url_for('backup.index'))


@backup_bp.route('/delete', methods=['POST'])
@login_required
def delete():
    """Delete backup"""
    backup_name = request.form.get('backup_name')
    
    result = BackupService.delete_backup(backup_name)
    
    if result['success']:
        flash('Backup deleted.', 'success')
    else:
        flash(f"Delete failed: {result.get('error', 'Unknown error')}", 'danger')
    
    return redirect(url_for('backup.index'))


@backup_bp.route('/export-json')
@login_required
def export_json():
    """Export data as JSON"""
    result = BackupService.export_data_json()
    
    if result['success']:
        return jsonify(result['data'])
    else:
        flash(f"Export failed: {result.get('error', 'Unknown error')}", 'danger')
        return redirect(url_for('backup.index'))


@backup_bp.route('/api/create', methods=['POST'])
@login_required
def api_create():
    """Create backup via API"""
    data = request.get_json() or {}
    result = BackupService.create_backup(include_uploads=data.get('include_uploads', True))
    return jsonify(result)
