"""First Launch Wizard Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request
from models import db
from models.user import User, UserRole
from models.settings import BusinessSettings
from models.inventory import Warehouse
from models.payment import Currency
from services.auth_service import AuthService
from services.settings_service import SettingsService

wizard_bp = Blueprint('wizard', __name__, template_folder='templates')


@wizard_bp.route('/')
@wizard_bp.route('/setup')
def setup():
    """First launch wizard"""
    # Check if setup is already completed
    settings = BusinessSettings.query.first()
    if settings and settings.setup_completed:
        return redirect(url_for('dashboard.index'))
    
    # Check if users exist
    existing_users = User.query.count()
    
    return render_template('wizard/setup.html', existing_users=existing_users)


@wizard_bp.route('/save', methods=['POST'])
def save_setup():
    """Save wizard data"""
    try:
        # Step 1: Create admin user if not exists
        existing_users = User.query.count()
        if existing_users == 0:
            user_data = {
                'username': request.form.get('admin_username', 'admin'),
                'email': request.form.get('admin_email'),
                'password': request.form.get('admin_password'),
                'first_name': request.form.get('admin_first_name', 'Admin'),
                'last_name': request.form.get('admin_last_name', ''),
                'phone': request.form.get('admin_phone', ''),
                'role_ids': [1]  # Super Admin
            }
            
            user, message = AuthService.create_user(user_data)
            if not user:
                flash(f'Error creating admin: {message}', 'danger')
                return redirect(url_for('wizard.setup'))
        
        # Step 2: Business settings
        settings = BusinessSettings.query.first()
        if not settings:
            settings = BusinessSettings()
            db.session.add(settings)
        
        settings.business_name = request.form.get('business_name', 'My Business')
        settings.store_name = request.form.get('store_name', 'My Store')
        settings.tagline = request.form.get('tagline', '')
        settings.owner_name = request.form.get('owner_name', '')
        settings.owner_email = request.form.get('owner_email', '')
        settings.owner_phone = request.form.get('owner_phone', '')
        settings.address = request.form.get('address', '')
        settings.city = request.form.get('city', '')
        settings.state = request.form.get('state', '')
        settings.country = request.form.get('country', '')
        settings.postal_code = request.form.get('postal_code', '')
        settings.gst_number = request.form.get('gst_number', '')
        settings.phone = request.form.get('business_phone', '')
        settings.email = request.form.get('business_email', '')
        settings.website = request.form.get('website', '')
        settings.currency_id = request.form.get('currency_id', type=int)
        settings.timezone = request.form.get('timezone', 'UTC')
        settings.language = request.form.get('language', 'en')
        settings.invoice_prefix = request.form.get('invoice_prefix', 'INV')
        settings.setup_completed = True
        
        # Step 3: Create default warehouse if not exists
        if Warehouse.query.count() == 0:
            warehouse = Warehouse(
                name='Main Warehouse',
                code='MAIN001',
                address=request.form.get('address', ''),
                city=request.form.get('city', ''),
                state=request.form.get('state', ''),
                country=request.form.get('country', ''),
                is_primary=True,
                is_active=True
            )
            db.session.add(warehouse)
        
        # Step 4: Create default currency if not exists
        if Currency.query.count() == 0:
            currency = Currency(
                code='INR',
                name='Indian Rupee',
                symbol='₹',
                is_base=True,
                is_active=True
            )
            db.session.add(currency)
            settings.currency_id = currency.id
        
        db.session.commit()
        
        flash('Setup completed successfully! Please log in.', 'success')
        return redirect(url_for('auth.login'))
    
    except Exception as e:
        db.session.rollback()
        flash(f'Error during setup: {str(e)}', 'danger')
        return redirect(url_for('wizard.setup'))
