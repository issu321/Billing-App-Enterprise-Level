"""Barcode and QR Code Routes"""
from flask import Blueprint, render_template, request, jsonify, send_file
from flask_login import login_required
from services.barcode_service import BarcodeService
from services.product_service import ProductService

barcode_bp = Blueprint('barcode', __name__, template_folder='templates')


@barcode_bp.route('/')
@login_required
def index():
    """Barcode generator page"""
    barcode_types = BarcodeService.get_barcode_types()
    products = ProductService.get_all_products(per_page=50)
    return render_template('barcode/index.html', barcode_types=barcode_types, products=products)


@barcode_bp.route('/generate', methods=['POST'])
@login_required
def generate():
    """Generate barcode"""
    data = request.get_json() or request.form.to_dict()
    
    barcode_type = data.get('barcode_type', 'code128')
    barcode_data = data.get('data', '')
    
    if not barcode_data:
        return jsonify({'success': False, 'message': 'No data provided'})
    
    result = BarcodeService.generate_barcode(barcode_data, barcode_type)
    return jsonify(result)


@barcode_bp.route('/generate-qr', methods=['POST'])
@login_required
def generate_qr():
    """Generate QR code"""
    data = request.get_json() or request.form.to_dict()
    
    qr_data = data.get('data', '')
    size = int(data.get('size', 10))
    
    if not qr_data:
        return jsonify({'success': False, 'message': 'No data provided'})
    
    result = BarcodeService.generate_qr_code(qr_data, size=size)
    return jsonify(result)


@barcode_bp.route('/generate-upi-qr', methods=['POST'])
@login_required
def generate_upi_qr():
    """Generate UPI payment QR code"""
    data = request.get_json() or request.form.to_dict()
    
    upi_id = data.get('upi_id', '')
    name = data.get('name')
    amount = data.get('amount')
    transaction_note = data.get('transaction_note')
    
    if not upi_id:
        return jsonify({'success': False, 'message': 'UPI ID is required'})
    
    result = BarcodeService.generate_upi_qr(upi_id, name, amount, transaction_note)
    return jsonify(result)


@barcode_bp.route('/product/<int:product_id>')
@login_required
def product_barcode(product_id):
    """Generate barcode for product"""
    product = ProductService.get_product_by_id(product_id)
    if not product:
        return jsonify({'success': False, 'message': 'Product not found'})
    
    barcode_result = BarcodeService.generate_product_barcode(product)
    qr_result = BarcodeService.generate_product_qr(product)
    
    return jsonify({
        'success': True,
        'barcode': barcode_result,
        'qr_code': qr_result,
        'product': product.to_dict()
    })


@barcode_bp.route('/print-labels', methods=['POST'])
@login_required
def print_labels():
    """Generate barcode labels for multiple products"""
    data = request.get_json()
    product_ids = data.get('product_ids', [])
    
    if not product_ids:
        return jsonify({'success': False, 'message': 'No products selected'})
    
    products = []
    for pid in product_ids:
        p = ProductService.get_product_by_id(pid)
        if p:
            products.append(p)
    
    results = BarcodeService.generate_bulk_barcodes(products)
    return jsonify({'success': True, 'labels': results})
