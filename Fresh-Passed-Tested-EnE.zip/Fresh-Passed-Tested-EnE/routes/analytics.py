"""Analytics Routes"""
from flask import Blueprint, render_template, jsonify, request
from flask_login import login_required
from services.report_service import ReportService
from services.sale_service import SaleService

analytics_bp = Blueprint('analytics', __name__, template_folder='templates')


@analytics_bp.route('/')
@login_required
def index():
    """Analytics dashboard"""
    summary = ReportService.get_dashboard_summary()
    daily_sales = SaleService.get_daily_sales(days=30)
    top_products = SaleService.get_top_selling_products(limit=10)
    yearly_comparison = ReportService.get_yearly_comparison()
    
    return render_template('analytics/index.html',
                         summary=summary,
                         daily_sales=daily_sales,
                         top_products=top_products,
                         yearly_comparison=yearly_comparison)


@analytics_bp.route('/api/dashboard-data')
@login_required
def api_dashboard_data():
    """Get dashboard analytics data"""
    summary = ReportService.get_dashboard_summary()
    daily_sales = SaleService.get_daily_sales(days=7)
    top_products = SaleService.get_top_selling_products(limit=5)
    
    return jsonify({
        'success': True,
        'summary': summary,
        'daily_sales': daily_sales,
        'top_products': top_products
    })
