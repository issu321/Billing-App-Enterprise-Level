"""Billing Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.sale_service import SaleService
from services.customer_service import CustomerService

billing_bp = Blueprint('billing', __name__, template_folder='templates')


@billing_bp.route('/')
@login_required
def index():
    """Sales/Billing list"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    payment_status = request.args.get('payment_status')
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    
    sales = SaleService.get_all_sales(
        page=page, search=search, payment_status=payment_status,
        date_from=date_from, date_to=date_to
    )
    
    return render_template('billing/index.html', sales=sales, search=search)


@billing_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Create new invoice/sale"""
    if request.method == 'POST':
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        # Handle form data conversion
        if not request.is_json:
            items = []
            i = 0
            while f'items[{i}][product_id]' in request.form:
                items.append({
                    'product_id': int(request.form.get(f'items[{i}][product_id]')),
                    'quantity': float(request.form.get(f'items[{i}][quantity]', 1)),
                    'unit_price': float(request.form.get(f'items[{i}][unit_price]', 0)),
                    'discount_percent': float(request.form.get(f'items[{i}][discount_percent]', 0)),
                    'tax_rate': float(request.form.get(f'items[{i}][tax_rate]', 0))
                })
                i += 1
            data['items'] = items
        
        sale, message = SaleService.create_sale(data, created_by=current_user.id)
        
        if sale:
            if request.is_json:
                return jsonify({'success': True, 'sale': sale.to_dict()})
            flash('Invoice created successfully!', 'success')
            return redirect(url_for('billing.view', id=sale.id))
        else:
            if request.is_json:
                return jsonify({'success': False, 'message': message})
            flash(message, 'danger')
    
    return render_template('billing/create.html')


@billing_bp.route('/view/<int:id>')
@login_required
def view(id):
    """View invoice"""
    sale = SaleService.get_sale_by_id(id)
    if not sale:
        flash('Invoice not found.', 'danger')
        return redirect(url_for('billing.index'))
    return render_template('billing/view.html', sale=sale)


@billing_bp.route('/print/<int:id>')
@login_required
def print_invoice(id):
    """Print invoice"""
    sale = SaleService.get_sale_by_id(id)
    if not sale:
        flash('Invoice not found.', 'danger')
        return redirect(url_for('billing.index'))
    return render_template('billing/print.html', sale=sale)


@billing_bp.route('/api/create', methods=['POST'])
@login_required
def api_create():
    """Create sale via API"""
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'No data provided'}), 400
    
    sale, message = SaleService.create_sale(data, created_by=current_user.id)
    
    if sale:
        return jsonify({'success': True, 'sale': sale.to_dict()})
    return jsonify({'success': False, 'message': message}), 400
