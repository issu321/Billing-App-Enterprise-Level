"""Settings Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.settings_service import SettingsService
from services.inventory_service import InventoryService

settings_bp = Blueprint('settings', __name__, template_folder='templates')


@settings_bp.route('/')
@login_required
def index():
    """Settings page"""
    settings = SettingsService.get_settings()
    warehouses = InventoryService.get_all_warehouses(is_active=True)
    currencies = SettingsService.get_currencies()
    tax_settings = SettingsService.get_tax_settings()
    
    return render_template('settings/index.html',
                         settings=settings,
                         warehouses=warehouses,
                         currencies=currencies,
                         tax_settings=tax_settings)


@settings_bp.route('/update', methods=['POST'])
@login_required
def update():
    """Update settings"""
    data = request.form.to_dict()
    
    # Handle boolean checkboxes
    boolean_fields = [
        'show_logo_on_invoice', 'auto_email_invoice', 'enable_pos', 'auto_print_receipt',
        'enable_inventory_tracking', 'enable_negative_stock', 'enable_multi_warehouse',
        'enable_barcode', 'enable_qr_payments', 'enable_customer_loyalty',
        'enable_serial_tracking', 'enable_batch_tracking', 'enable_expiry_tracking',
        'tax_inclusive_pricing', 'enable_multiple_tax'
    ]
    
    for field in boolean_fields:
        data[field] = field in request.form
    
    # Convert numeric fields
    numeric_fields = [
        'invoice_starting_number', 'default_warehouse_id', 'currency_id',
        'default_tax_rate', 'quantity_decimal_places', 'price_decimal_places',
        'amount_decimal_places'
    ]
    
    for field in numeric_fields:
        if field in data and data[field]:
            try:
                data[field] = float(data[field])
                if field in ['invoice_starting_number', 'default_warehouse_id', 'currency_id',
                           'quantity_decimal_places', 'price_decimal_places', 'amount_decimal_places']:
                    data[field] = int(data[field])
            except ValueError:
                pass
    
    settings, message = SettingsService.update_settings(data)
    
    if settings:
        flash('Settings updated successfully!', 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('settings.index'))


@settings_bp.route('/tax/create', methods=['POST'])
@login_required
def create_tax():
    """Create tax setting"""
    data = {
        'name': request.form.get('name'),
        'tax_type': request.form.get('tax_type', 'gst'),
        'rate': request.form.get('rate', type=float, default=0),
        'cgst_rate': request.form.get('cgst_rate', type=float, default=0),
        'sgst_rate': request.form.get('sgst_rate', type=float, default=0),
        'igst_rate': request.form.get('igst_rate', type=float, default=0),
        'cess_rate': request.form.get('cess_rate', type=float, default=0),
        'hsn_code_prefix': request.form.get('hsn_code_prefix'),
        'description': request.form.get('description'),
        'is_default': request.form.get('is_default') == 'on',
        'is_active': request.form.get('is_active') != 'off'
    }
    
    tax, message = SettingsService.create_tax_setting(data)
    if tax:
        flash('Tax setting created!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('settings.index'))


@settings_bp.route('/tax/edit/<int:id>', methods=['POST'])
@login_required
def edit_tax(id):
    """Edit tax setting"""
    data = {
        'name': request.form.get('name'),
        'tax_type': request.form.get('tax_type'),
        'rate': request.form.get('rate', type=float),
        'cgst_rate': request.form.get('cgst_rate', type=float),
        'sgst_rate': request.form.get('sgst_rate', type=float),
        'igst_rate': request.form.get('igst_rate', type=float),
        'cess_rate': request.form.get('cess_rate', type=float),
        'hsn_code_prefix': request.form.get('hsn_code_prefix'),
        'description': request.form.get('description'),
        'is_active': request.form.get('is_active') == 'on',
        'is_default': request.form.get('is_default') == 'on'
    }
    
    tax, message = SettingsService.update_tax_setting(id, data)
    if tax:
        flash('Tax setting updated!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('settings.index'))


@settings_bp.route('/tax/delete/<int:id>', methods=['POST'])
@login_required
def delete_tax(id):
    """Delete tax setting"""
    success, message = SettingsService.delete_tax_setting(id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('settings.index'))


@settings_bp.route('/currency/create', methods=['POST'])
@login_required
def create_currency():
    """Create currency"""
    data = {
        'code': request.form.get('code'),
        'name': request.form.get('name'),
        'symbol': request.form.get('symbol'),
        'exchange_rate': request.form.get('exchange_rate', type=float, default=1.0),
        'is_base': request.form.get('is_base') == 'on',
        'is_active': request.form.get('is_active') != 'off'
    }
    
    currency, message = SettingsService.create_currency(data)
    if currency:
        flash('Currency created!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('settings.index'))
