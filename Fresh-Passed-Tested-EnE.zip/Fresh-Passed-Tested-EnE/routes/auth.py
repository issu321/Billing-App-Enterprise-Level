"""Authentication Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, session, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from services.auth_service import AuthService
from models.user import User
from models import db

auth_bp = Blueprint('auth', __name__, template_folder='templates')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    if request.method == 'POST':
        username_or_email = request.form.get('username_or_email')
        password = request.form.get('password')
        # FIX: Convert checkbox string to boolean properly
        remember = request.form.get('remember') in ['on', 'true', 'True', '1', 'yes', 'checked']
        
        if not username_or_email or not password:
            flash('Please enter both username/email and password.', 'warning')
            return render_template('auth/login.html')
        
        user, message = AuthService.authenticate_user(username_or_email, password)
        
        if user:
            # FIX: Explicitly login the user
            login_user(user, remember=remember)
            flash(f'Welcome back, {user.get_full_name()}!', 'success')
            
            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            return redirect(url_for('dashboard.index'))
        else:
            flash(message, 'danger')
    
    return render_template('auth/login.html')


@auth_bp.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('auth.login'))


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration - typically disabled in production, used for first admin"""
    # Check if any users exist
    existing_users = User.query.count()
    
    if request.method == 'POST':
        data = {
            'username': request.form.get('username'),
            'email': request.form.get('email'),
            'password': request.form.get('password'),
            'first_name': request.form.get('first_name'),
            'last_name': request.form.get('last_name'),
            'phone': request.form.get('phone')
        }
        
        if existing_users == 0:
            # First user gets super admin role
            data['role_ids'] = [1]  # Super Admin
        
        user, message = AuthService.create_user(data)
        
        if user:
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('auth.login'))
        else:
            flash(message, 'danger')
    
    return render_template('auth/register.html', first_user=(existing_users == 0))


@auth_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """User profile"""
    if request.method == 'POST':
        data = {
            'first_name': request.form.get('first_name'),
            'last_name': request.form.get('last_name'),
            'phone': request.form.get('phone'),
            'email': request.form.get('email'),
            'language': request.form.get('language', 'en'),
            'timezone': request.form.get('timezone', 'UTC')
        }
        
        password = request.form.get('password')
        if password:
            data['password'] = password
        
        user, message = AuthService.update_user(current_user.id, data)
        
        if user:
            flash('Profile updated successfully!', 'success')
        else:
            flash(message, 'danger')
    
    return render_template('auth/profile.html', user=current_user)


# API endpoints
@auth_bp.route('/api/login', methods=['POST'])
def api_login():
    """API login endpoint"""
    data = request.get_json()
    
    if not data:
        return jsonify({'success': False, 'message': 'No data provided'}), 400
    
    username_or_email = data.get('username_or_email')
    password = data.get('password')
    
    if not username_or_email or not password:
        return jsonify({'success': False, 'message': 'Username/email and password required'}), 400
    
    user, message = AuthService.authenticate_user(username_or_email, password)
    
    if user:
        login_user(user, remember=data.get('remember', False))
        return jsonify({
            'success': True,
            'message': message,
            'user': user.to_dict()
        })
    
    return jsonify({'success': False, 'message': message}), 401


@auth_bp.route('/api/logout', methods=['POST'])
@login_required
def api_logout():
    """API logout endpoint"""
    logout_user()
    return jsonify({'success': True, 'message': 'Logged out successfully'})