"""Inventory Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.inventory_service import InventoryService
from services.product_service import ProductService

inventory_bp = Blueprint('inventory', __name__, template_folder='templates')


@inventory_bp.route('/')
@login_required
def index():
    """Inventory list"""
    page = request.args.get('page', 1, type=int)
    warehouse_id = request.args.get('warehouse_id', type=int)
    low_stock_only = request.args.get('low_stock') == '1'
    
    inventory = InventoryService.get_all_inventory(
        page=page, warehouse_id=warehouse_id, low_stock_only=low_stock_only
    )
    warehouses = InventoryService.get_all_warehouses(is_active=True)
    stats = InventoryService.get_inventory_stats()
    
    return render_template('inventory/index.html',
                         inventory=inventory,
                         warehouses=warehouses,
                         stats=stats,
                         warehouse_id=warehouse_id,
                         low_stock_only=low_stock_only)


@inventory_bp.route('/warehouses')
@login_required
def warehouses():
    """Warehouse list"""
    warehouses = InventoryService.get_all_warehouses()
    return render_template('inventory/warehouses.html', warehouses=warehouses)


@inventory_bp.route('/warehouses/create', methods=['POST'])
@login_required
def create_warehouse():
    """Create warehouse"""
    data = {
        'name': request.form.get('name'),
        'code': request.form.get('code'),
        'address': request.form.get('address'),
        'city': request.form.get('city'),
        'state': request.form.get('state'),
        'country': request.form.get('country'),
        'postal_code': request.form.get('postal_code'),
        'phone': request.form.get('phone'),
        'email': request.form.get('email'),
        'manager_name': request.form.get('manager_name'),
        'is_primary': request.form.get('is_primary') == 'on',
        'notes': request.form.get('notes')
    }
    
    warehouse, message = InventoryService.create_warehouse(data)
    if warehouse:
        flash('Warehouse created successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('inventory.warehouses'))


@inventory_bp.route('/warehouses/edit/<int:id>', methods=['POST'])
@login_required
def edit_warehouse(id):
    """Edit warehouse"""
    data = {
        'name': request.form.get('name'),
        'address': request.form.get('address'),
        'city': request.form.get('city'),
        'state': request.form.get('state'),
        'country': request.form.get('country'),
        'postal_code': request.form.get('postal_code'),
        'phone': request.form.get('phone'),
        'email': request.form.get('email'),
        'manager_name': request.form.get('manager_name'),
        'is_primary': request.form.get('is_primary') == 'on',
        'is_active': request.form.get('is_active') == 'on',
        'notes': request.form.get('notes')
    }
    
    warehouse, message = InventoryService.update_warehouse(id, data)
    if warehouse:
        flash('Warehouse updated successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('inventory.warehouses'))


@inventory_bp.route('/warehouses/delete/<int:id>', methods=['POST'])
@login_required
def delete_warehouse(id):
    """Delete warehouse"""
    success, message = InventoryService.delete_warehouse(id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('inventory.warehouses'))


@inventory_bp.route('/adjust', methods=['POST'])
@login_required
def adjust_stock():
    """Adjust stock"""
    data = {
        'product_id': request.form.get('product_id', type=int),
        'warehouse_id': request.form.get('warehouse_id', type=int),
        'quantity_after': request.form.get('quantity_after', type=float),
        'adjustment_type': request.form.get('adjustment_type', 'system'),
        'reason': request.form.get('reason'),
        'notes': request.form.get('notes')
    }
    
    adjustment, message = InventoryService.adjust_stock(data, created_by=current_user.id)
    if adjustment:
        flash('Stock adjusted successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('inventory.index'))


@inventory_bp.route('/transfer', methods=['POST'])
@login_required
def transfer_stock():
    """Transfer stock between warehouses"""
    data = {
        'product_id': request.form.get('product_id', type=int),
        'from_warehouse_id': request.form.get('from_warehouse_id', type=int),
        'to_warehouse_id': request.form.get('to_warehouse_id', type=int),
        'quantity': request.form.get('quantity', type=float),
        'reference_number': request.form.get('reference_number')
    }
    
    result, message = InventoryService.transfer_stock(data, created_by=current_user.id)
    if result:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('inventory.index'))


@inventory_bp.route('/transactions')
@login_required
def transactions():
    """Inventory transactions"""
    page = request.args.get('page', 1, type=int)
    product_id = request.args.get('product_id', type=int)
    warehouse_id = request.args.get('warehouse_id', type=int)
    
    transactions = InventoryService.get_inventory_transactions(
        page=page, product_id=product_id, warehouse_id=warehouse_id
    )
    
    return render_template('inventory/transactions.html', transactions=transactions)


@inventory_bp.route('/api/stats')
@login_required
def api_stats():
    """Get inventory stats"""
    stats = InventoryService.get_inventory_stats()
    return jsonify({'success': True, 'data': stats})


@inventory_bp.route('/api/low-stock')
@login_required
def api_low_stock():
    """Get low stock items"""
    products = ProductService.get_low_stock_products()
    return jsonify({
        'success': True,
        'products': [p.to_dict() for p in products]
    })
