"""POS Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, session
from flask_login import login_required, current_user
from services.sale_service import SaleService
from services.product_service import ProductService
from services.customer_service import CustomerService
from services.settings_service import SettingsService

pos_bp = Blueprint('pos', __name__, template_folder='templates')


@pos_bp.route('/')
@login_required
def index():
    """POS interface"""
    settings = SettingsService.get_settings()
    categories = [{'id': c.id, 'name': c.name, 'color': c.color} for c in 
                  __import__('services.category_service', fromlist=['CategoryService']).CategoryService.get_all_categories(is_active=True)]
    
    return render_template('pos/index.html', 
                         categories=categories,
                         settings=settings,
                         currency_symbol='₹')


@pos_bp.route('/checkout', methods=['POST'])
@login_required
def checkout():
    """Process POS checkout"""
    data = request.get_json()
    
    if not data or not data.get('items'):
        return jsonify({'success': False, 'message': 'No items in cart'}), 400
    
    sale_data = {
        'is_pos_sale': True,
        'counter_number': data.get('counter_number', '1'),
        'cashier_id': current_user.id,
        'customer_id': data.get('customer_id'),
        'customer_name': data.get('customer_name', 'Walk-in Customer'),
        'customer_phone': data.get('customer_phone'),
        'payment_method': data.get('payment_method', 'cash'),
        'paid_amount': data.get('paid_amount', 0),
        'discount_type': data.get('discount_type', 'none'),
        'discount_value': data.get('discount_value', 0),
        'tax_rate': data.get('tax_rate', 0),
        'notes': data.get('notes'),
        'items': data['items']
    }
    
    sale, message = SaleService.create_sale(sale_data, created_by=current_user.id)
    
    if sale:
        return jsonify({
            'success': True,
            'message': message,
            'sale': sale.to_dict()
        })
    
    return jsonify({'success': False, 'message': message}), 400


@pos_bp.route('/receipt/<int:sale_id>')
@login_required
def receipt(sale_id):
    """Print receipt"""
    sale = SaleService.get_sale_by_id(sale_id)
    if not sale:
        flash('Sale not found.', 'danger')
        return redirect(url_for('pos.index'))
    
    settings = SettingsService.get_settings()
    return render_template('pos/receipt.html', sale=sale, settings=settings)
