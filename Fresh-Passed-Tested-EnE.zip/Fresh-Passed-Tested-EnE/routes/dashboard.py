"""Dashboard Routes"""
from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from services.report_service import ReportService
from services.product_service import ProductService
from services.sale_service import SaleService


from flask import request
dashboard_bp = Blueprint('dashboard', __name__, template_folder='templates')


@dashboard_bp.route('/')
@login_required
def index():
    """Main dashboard"""
    summary = ReportService.get_dashboard_summary()
    daily_sales = SaleService.get_daily_sales(days=7)
    top_products = SaleService.get_top_selling_products(limit=5)
    product_stats = ProductService.get_product_stats()
    recent_sales_data = SaleService.get_all_sales(page=1, per_page=10)
    
    return render_template('dashboard/index.html',
                         summary=summary,
                         daily_sales=daily_sales,
                         top_products=top_products,
                         product_stats=product_stats,
                         recent_sales=recent_sales_data.items if recent_sales_data else [])


@dashboard_bp.route('/api/summary')
@login_required
def api_summary():
    """Get dashboard summary data"""
    summary = ReportService.get_dashboard_summary()
    return jsonify({'success': True, 'data': summary})


@dashboard_bp.route('/api/daily-sales')
@login_required
def api_daily_sales():
    """Get daily sales data"""
    days = request.args.get('days', 7, type=int)
    daily_sales = SaleService.get_daily_sales(days=days)
    return jsonify({'success': True, 'data': daily_sales})


@dashboard_bp.route('/api/top-products')
@login_required
def api_top_products():
    """Get top selling products"""
    limit = request.args.get('limit', 5, type=int)
    top_products = SaleService.get_top_selling_products(limit=limit)
    return jsonify({'success': True, 'data': top_products})