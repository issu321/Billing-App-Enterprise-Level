"""Payment Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.settings_service import SettingsService

payments_bp = Blueprint('payments', __name__, template_folder='templates')


@payments_bp.route('/')
@login_required
def index():
    """Payment methods"""
    methods = SettingsService.get_payment_methods()
    accounts = SettingsService.get_accounts()
    return render_template('payments/index.html', methods=methods, accounts=accounts)


@payments_bp.route('/methods/create', methods=['POST'])
@login_required
def create_method():
    """Create payment method"""
    data = {
        'name': request.form.get('name'),
        'code': request.form.get('code'),
        'description': request.form.get('description'),
        'icon': request.form.get('icon'),
        'requires_reference': request.form.get('requires_reference') == 'on',
        'processing_fee_percent': request.form.get('processing_fee_percent', type=float, default=0),
        'sort_order': request.form.get('sort_order', type=int, default=0)
    }
    
    method, message = SettingsService.create_payment_method(data)
    if method:
        flash('Payment method created!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('payments.index'))


@payments_bp.route('/accounts/create', methods=['POST'])
@login_required
def create_account():
    """Create financial account"""
    data = {
        'name': request.form.get('name'),
        'account_number': request.form.get('account_number'),
        'account_type': request.form.get('account_type', 'bank'),
        'bank_name': request.form.get('bank_name'),
        'branch_name': request.form.get('branch_name'),
        'ifsc_code': request.form.get('ifsc_code'),
        'upi_id': request.form.get('upi_id'),
        'opening_balance': request.form.get('opening_balance', type=float, default=0)
    }
    
    account, message = SettingsService.create_account(data)
    if account:
        flash('Account created!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('payments.index'))


@payments_bp.route('/upi-qr')
@login_required
def upi_qr():
    """UPI QR Code generation page"""
    accounts = SettingsService.get_accounts()
    return render_template('payments/upi_qr.html', accounts=accounts)
