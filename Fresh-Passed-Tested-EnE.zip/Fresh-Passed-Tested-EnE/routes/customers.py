"""Customer Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.customer_service import CustomerService

customers_bp = Blueprint('customers', __name__, template_folder='templates')


@customers_bp.route('/')
@login_required
def index():
    """Customer list"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    group_id = request.args.get('group_id', type=int)
    
    customers = CustomerService.get_all_customers(
        page=page, search=search, group_id=group_id
    )
    groups = CustomerService.get_all_groups()
    stats = CustomerService.get_customer_stats()
    
    return render_template('customers/index.html',
                         customers=customers,
                         groups=groups,
                         stats=stats,
                         search=search)


@customers_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Create customer"""
    groups = CustomerService.get_all_groups()
    
    if request.method == 'POST':
        data = {
            'customer_code': request.form.get('customer_code'),
            'name': request.form.get('name'),
            'email': request.form.get('email'),
            'phone': request.form.get('phone'),
            'mobile': request.form.get('mobile'),
            'group_id': request.form.get('group_id', type=int),
            'customer_type': request.form.get('customer_type', 'retail'),
            'address': request.form.get('address'),
            'city': request.form.get('city'),
            'state': request.form.get('state'),
            'postal_code': request.form.get('postal_code'),
            'gst_number': request.form.get('gst_number'),
            'credit_limit': request.form.get('credit_limit', type=float, default=0),
            'credit_days': request.form.get('credit_days', type=int, default=0),
            'notes': request.form.get('notes')
        }
        
        customer, message = CustomerService.create_customer(data, created_by=current_user.id)
        if customer:
            flash('Customer created successfully!', 'success')
            return redirect(url_for('customers.index'))
        else:
            flash(message, 'danger')
    
    return render_template('customers/create.html', groups=groups)


@customers_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    """Edit customer"""
    customer = CustomerService.get_customer_by_id(id)
    if not customer:
        flash('Customer not found.', 'danger')
        return redirect(url_for('customers.index'))
    
    groups = CustomerService.get_all_groups()
    
    if request.method == 'POST':
        data = {
            'name': request.form.get('name'),
            'email': request.form.get('email'),
            'phone': request.form.get('phone'),
            'mobile': request.form.get('mobile'),
            'group_id': request.form.get('group_id', type=int),
            'address': request.form.get('address'),
            'city': request.form.get('city'),
            'state': request.form.get('state'),
            'postal_code': request.form.get('postal_code'),
            'gst_number': request.form.get('gst_number'),
            'credit_limit': request.form.get('credit_limit', type=float),
            'credit_days': request.form.get('credit_days', type=int),
            'notes': request.form.get('notes'),
            'is_active': request.form.get('is_active') == 'on'
        }
        
        customer, message = CustomerService.update_customer(id, data)
        if customer:
            flash('Customer updated successfully!', 'success')
            return redirect(url_for('customers.index'))
        else:
            flash(message, 'danger')
    
    return render_template('customers/edit.html', customer=customer, groups=groups)


@customers_bp.route('/delete/<int:id>', methods=['POST'])
@login_required
def delete(id):
    """Delete customer"""
    success, message = CustomerService.delete_customer(id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('customers.index'))


@customers_bp.route('/view/<int:id>')
@login_required
def view(id):
    """View customer details"""
    customer = CustomerService.get_customer_by_id(id)
    if not customer:
        flash('Customer not found.', 'danger')
        return redirect(url_for('customers.index'))
    
    ledger = CustomerService.get_customer_ledger(id)
    return render_template('customers/view.html', customer=customer, ledger=ledger)


@customers_bp.route('/ledger/<int:id>')
@login_required
def ledger(id):
    """Customer ledger"""
    customer = CustomerService.get_customer_by_id(id)
    if not customer:
        flash('Customer not found.', 'danger')
        return redirect(url_for('customers.index'))
    
    ledger_entries = CustomerService.get_customer_ledger(id)
    return render_template('customers/ledger.html', customer=customer, ledger=ledger_entries)


@customers_bp.route('/groups/create', methods=['POST'])
@login_required
def create_group():
    """Create customer group"""
    data = {
        'name': request.form.get('name'),
        'description': request.form.get('description'),
        'discount_percent': request.form.get('discount_percent', type=float, default=0),
        'price_level': request.form.get('price_level', 'retail')
    }
    
    group, message = CustomerService.create_group(data)
    if group:
        flash('Customer group created!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('customers.index'))


@customers_bp.route('/api/search')
@login_required
def api_search():
    """Search customers"""
    q = request.args.get('q', '')
    if len(q) < 2:
        return jsonify({'success': True, 'customers': []})
    
    from models.customer import Customer
    from models import db
    customers = Customer.query.filter(
        db.or_(
            Customer.name.ilike(f'%{q}%'),
            Customer.phone.ilike(f'%{q}%'),
            Customer.customer_code.ilike(f'%{q}%')
        ),
        Customer.is_active == True
    ).limit(10).all()
    
    return jsonify({
        'success': True,
        'customers': [c.to_dict() for c in customers]
    })
