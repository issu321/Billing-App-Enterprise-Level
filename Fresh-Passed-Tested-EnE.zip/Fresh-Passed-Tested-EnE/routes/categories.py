"""Category Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required
from services.category_service import CategoryService

categories_bp = Blueprint('categories', __name__, template_folder='templates')


@categories_bp.route('/')
@login_required
def index():
    """Category list"""
    categories = CategoryService.get_all_categories()
    stats = CategoryService.get_category_stats()
    return render_template('categories/index.html', categories=categories, stats=stats)


@categories_bp.route('/create', methods=['POST'])
@login_required
def create():
    """Create category"""
    data = {
        'name': request.form.get('name'),
        'code': request.form.get('code'),
        'description': request.form.get('description'),
        'parent_id': request.form.get('parent_id', type=int) or None,
        'color': request.form.get('color', '#4F46E5'),
        'icon': request.form.get('icon'),
        'sort_order': request.form.get('sort_order', type=int, default=0)
    }
    
    category, message = CategoryService.create_category(data)
    if category:
        flash('Category created successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('categories.index'))


@categories_bp.route('/edit/<int:id>', methods=['POST'])
@login_required
def edit(id):
    """Edit category"""
    data = {
        'name': request.form.get('name'),
        'code': request.form.get('code'),
        'description': request.form.get('description'),
        'parent_id': request.form.get('parent_id', type=int) or None,
        'color': request.form.get('color', '#4F46E5'),
        'icon': request.form.get('icon'),
        'sort_order': request.form.get('sort_order', type=int, default=0),
        'is_active': request.form.get('is_active') == 'on'
    }
    
    category, message = CategoryService.update_category(id, data)
    if category:
        flash('Category updated successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('categories.index'))


@categories_bp.route('/delete/<int:id>', methods=['POST'])
@login_required
def delete(id):
    """Delete category"""
    success, message = CategoryService.delete_category(id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('categories.index'))


@categories_bp.route('/api/list')
@login_required
def api_list():
    """Get categories as JSON"""
    categories = CategoryService.get_all_categories(is_active=True)
    return jsonify({
        'success': True,
        'categories': [c.to_dict() for c in categories]
    })


@categories_bp.route('/api/tree')
@login_required
def api_tree():
    """Get category tree as JSON"""
    tree = CategoryService.get_category_tree()
    return jsonify({'success': True, 'categories': tree})
