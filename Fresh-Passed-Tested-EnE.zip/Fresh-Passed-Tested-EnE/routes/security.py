"""Security and Audit Routes"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from services.auth_service import AuthService
from models.audit_log import AuditLog
from models.user import User

security_bp = Blueprint('security', __name__, template_folder='templates')


@security_bp.route('/')
@login_required
def index():
    """Security dashboard"""
    # Get recent audit logs
    recent_logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(50).all()
    
    # Get stats
    total_logs = AuditLog.query.count()
    failed_logins = AuditLog.query.filter_by(action='login', status='failed').count()
    
    return render_template('security/index.html', 
                         logs=recent_logs, 
                         total_logs=total_logs,
                         failed_logins=failed_logins)


@security_bp.route('/audit-logs')
@login_required
def audit_logs():
    """Audit logs page"""
    page = request.args.get('page', 1, type=int)
    action = request.args.get('action')
    entity_type = request.args.get('entity_type')
    
    query = AuditLog.query
    
    if action:
        query = query.filter(AuditLog.action == action)
    if entity_type:
        query = query.filter(AuditLog.entity_type == entity_type)
    
    logs = query.order_by(AuditLog.created_at.desc()).paginate(
        page=page, per_page=50, error_out=False
    )
    
    # Get filter options
    actions = db.session.query(AuditLog.action).distinct().all()
    entity_types = db.session.query(AuditLog.entity_type).distinct().all()
    
    return render_template('security/audit_logs.html',
                         logs=logs,
                         actions=[a[0] for a in actions],
                         entity_types=[e[0] for e in entity_types])


@security_bp.route('/users')
@login_required
def users():
    """User management"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    
    users = AuthService.get_all_users(page=page, search=search)
    roles = AuthService.get_all_roles()
    
    return render_template('security/users.html', users=users, roles=roles, search=search)


@security_bp.route('/users/create', methods=['POST'])
@login_required
def create_user():
    """Create user"""
    data = {
        'username': request.form.get('username'),
        'email': request.form.get('email'),
        'password': request.form.get('password'),
        'first_name': request.form.get('first_name'),
        'last_name': request.form.get('last_name'),
        'phone': request.form.get('phone'),
        'is_active': request.form.get('is_active') == 'on',
        'role_ids': [int(r) for r in request.form.getlist('role_ids')]
    }
    
    user, message = AuthService.create_user(data, created_by=current_user.id)
    if user:
        flash('User created successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('security.users'))


@security_bp.route('/users/edit/<int:id>', methods=['POST'])
@login_required
def edit_user(id):
    """Edit user"""
    data = {
        'first_name': request.form.get('first_name'),
        'last_name': request.form.get('last_name'),
        'phone': request.form.get('phone'),
        'email': request.form.get('email'),
        'is_active': request.form.get('is_active') == 'on',
        'role_ids': [int(r) for r in request.form.getlist('role_ids')]
    }
    
    password = request.form.get('password')
    if password:
        data['password'] = password
    
    user, message = AuthService.update_user(id, data, updated_by=current_user.id)
    if user:
        flash('User updated successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('security.users'))


@security_bp.route('/users/delete/<int:id>', methods=['POST'])
@login_required
def delete_user(id):
    """Delete user"""
    if id == current_user.id:
        flash('Cannot delete your own account.', 'danger')
        return redirect(url_for('security.users'))
    
    success, message = AuthService.delete_user(id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('security.users'))


@security_bp.route('/roles')
@login_required
def roles():
    """Role management"""
    roles = AuthService.get_all_roles()
    permissions = AuthService.get_all_permissions()
    return render_template('security/roles.html', roles=roles, permissions=permissions)


@security_bp.route('/roles/create', methods=['POST'])
@login_required
def create_role():
    """Create role"""
    data = {
        'name': request.form.get('name'),
        'description': request.form.get('description'),
        'permission_ids': [int(p) for p in request.form.getlist('permission_ids')]
    }
    
    role, message = AuthService.create_role(data)
    if role:
        flash('Role created successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('security.roles'))


@security_bp.route('/roles/edit/<int:id>', methods=['POST'])
@login_required
def edit_role(id):
    """Edit role"""
    data = {
        'name': request.form.get('name'),
        'description': request.form.get('description'),
        'is_active': request.form.get('is_active') == 'on',
        'permission_ids': [int(p) for p in request.form.getlist('permission_ids')]
    }
    
    role, message = AuthService.update_role(id, data)
    if role:
        flash('Role updated successfully!', 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('security.roles'))


@security_bp.route('/roles/delete/<int:id>', methods=['POST'])
@login_required
def delete_role(id):
    """Delete role"""
    success, message = AuthService.delete_role(id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    return redirect(url_for('security.roles'))


from models import db
