"""Reports Routes"""
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from services.report_service import ReportService

reports_bp = Blueprint('reports', __name__, template_folder='templates')


@reports_bp.route('/')
@login_required
def index():
    """Reports dashboard"""
    summary = ReportService.get_dashboard_summary()
    return render_template('reports/index.html', summary=summary)


@reports_bp.route('/sales')
@login_required
def sales():
    """Sales report"""
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    
    report = ReportService.get_sales_report(date_from=date_from, date_to=date_to)
    return render_template('reports/sales.html', report=report, date_from=date_from, date_to=date_to)


@reports_bp.route('/products')
@login_required
def products():
    """Product performance report"""
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    
    products_report = ReportService.get_product_performance(date_from=date_from, date_to=date_to)
    return render_template('reports/products.html', products=products_report)


@reports_bp.route('/customers')
@login_required
def customers():
    """Customer report"""
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    
    customers_report = ReportService.get_customer_report(date_from=date_from, date_to=date_to)
    return render_template('reports/customers.html', customers=customers_report)


@reports_bp.route('/inventory')
@login_required
def inventory():
    """Inventory report"""
    warehouse_id = request.args.get('warehouse_id', type=int)
    report = ReportService.get_inventory_report(warehouse_id=warehouse_id)
    return render_template('reports/inventory.html', report=report)


@reports_bp.route('/payments')
@login_required
def payments():
    """Payment report"""
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    
    report = ReportService.get_payment_report(date_from=date_from, date_to=date_to)
    return render_template('reports/payments.html', report=report)


@reports_bp.route('/api/sales-chart')
@login_required
def api_sales_chart():
    """Get sales chart data"""
    period = request.args.get('period', 'monthly')
    data = ReportService.get_sales_by_period(period=period)
    return jsonify({'success': True, 'data': data})
