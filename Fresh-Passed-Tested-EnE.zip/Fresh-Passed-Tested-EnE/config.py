"""Enterprise Billing Platform - Configuration"""
import os
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, 'instance')
UPLOAD_DIR = os.path.join(BASE_DIR, 'static', 'uploads')
LOG_DIR = os.path.join(BASE_DIR, 'logs')

# Ensure directories exist
os.makedirs(INSTANCE_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)


class Config:
    """Base configuration"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'enterprise-billing-secret-key-2024'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or f'sqlite:///{os.path.join(INSTANCE_DIR, "billing.db")}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    PERMANENT_SESSION_LIFETIME = timedelta(hours=24)
    
    # Upload settings
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    UPLOAD_FOLDER = UPLOAD_DIR
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'csv', 'xlsx'}
    
    # Application settings
    APP_NAME = 'Enterprise Billing & POS'
    APP_VERSION = '1.0.0'
    COMPANY_NAME = 'Enterprise Billing Solutions'
    
    # Developer info
    DEVELOPER_NAME = 'Mohammed Usman'
    DEVELOPER_MOBILE = '8884294749'
    DEVELOPER_EMAIL = 'jaafreeusman@gmail.com'
    DEVELOPER_GITHUB = 'https://github.com/issu321'
    DEVELOPER_PORTFOLIO = 'https://issu321.github.io/issu321/'
    DEVELOPER_WHATSAPP = 'https://wa.me/918884294749'
    
    # Currency settings
    DEFAULT_CURRENCY = 'INR'
    CURRENCY_SYMBOLS = {
        'INR': '₹',
        'USD': '$',
        'EUR': '€',
        'GBP': '£',
        'AED': 'د.إ',
        'SAR': '﷼',
        'QAR': '﷼',
        'KWD': 'د.ك',
        'BHD': 'د.ب',
        'OMR': '﷼',
        'JOD': 'د.ا',
        'EGP': '£',
        'TRY': '₺',
        'PKR': '₨',
        'BDT': '৳',
        'LKR': 'Rs',
        'NPR': '₨',
        'MYR': 'RM',
        'SGD': '$',
        'AUD': '$',
        'CAD': '$',
        'CHF': 'Fr',
        'JPY': '¥',
        'CNY': '¥',
        'KRW': '₩',
        'THB': '฿',
        'VND': '₫',
        'PHP': '₱',
        'IDR': 'Rp',
        'RUB': '₽',
        'ZAR': 'R',
        'NGN': '₦',
        'KES': 'KSh',
        'GHS': '₵',
        'TZS': 'Sh',
        'UGX': 'Sh',
        'RWF': 'Fr',
        'BRL': 'R$',
        'MXN': '$',
        'ARS': '$',
        'CLP': '$',
        'COP': '$',
        'PEN': 'S/',
        'NZD': '$',
        'HKD': '$',
        'TWD': 'NT$',
        'DKK': 'kr',
        'NOK': 'kr',
        'SEK': 'kr',
        'PLN': 'zł',
        'CZK': 'Kč',
        'HUF': 'Ft',
        'RON': 'lei',
        'BGN': 'лв',
        'HRK': 'kn',
        'RSD': 'din',
        'UAH': '₴',
        'MAD': 'د.م.',
        'TND': 'د.ت',
        'DZD': 'د.ج',
        'LYD': 'ل.د',
        'SDG': 'ج.س.',
        'ETB': 'Br',
        'XOF': 'Fr',
        'XAF': 'Fr',
        'CDF': 'Fr',
        'BIF': 'Fr',
        'DJF': 'Fr',
        'GNF': 'Fr',
        'HTG': 'G',
        'MZN': 'MT',
        'SCR': '₨',
        'MUR': '₨',
        'MVR': '.ރ',
        'NAD': '$',
        'BWP': 'P',
        'ZMW': 'K',
        'MWK': 'MK',
        'SZL': 'E',
        'LSL': 'L',
        'MGA': 'Ar',
        'MRU': 'UM',
        'SLL': 'Le',
        'SOS': 'Sh',
        'SSP': '£',
        'STD': 'Db',
        'XCD': '$',
        'TTD': '$',
        'BBD': '$',
        'BZD': '$',
        'GYD': '$',
        'JMD': '$',
        'SRD': '$',
        'BOB': 'Bs',
        'PYG': '₲',
        'UYU': '$U',
        'CVE': '$',
        'GIP': '£',
        'FKP': '£',
        'SHP': '£',
        'AWG': 'ƒ',
        'ANG': 'ƒ',
        'BMD': '$',
        'KYD': '$',
        'BND': '$',
        'FJD': '$',
        'PGK': 'K',
        'SBD': '$',
        'TOP': 'T$',
        'VUV': 'Vt',
        'WST': 'T',
        'KID': '$',
        'CUP': '$',
        'DOP': '$',
        'HNL': 'L',
        'NIO': 'C$',
        'CRC': '₡',
        'GTQ': 'Q',
        'PAB': 'B/.',
        'SVC': '₡',
        'BZD': '$',
        'ISK': 'kr',
        'MKD': 'ден',
        'ALL': 'L',
        'BAM': 'KM',
        'MDL': 'L',
        'AMD': '֏',
        'AZN': '₼',
        'BYN': 'Br',
        'GEL': '₾',
        'KZT': '₸',
        'KGS': 'с',
        'TJS': 'ЅМ',
        'TMT': 'm',
        'UZS': 'soʻm',
        'AFN': '؋',
        'IRR': '﷼',
        'IQD': 'ع.د',
        'ILS': '₪',
        'JOD': 'د.ا',
        'KWD': 'د.ك',
        'LBP': 'ل.ل',
        'OMR': '﷼',
        'QAR': '﷼',
        'SAR': '﷼',
        'SYP': '£',
        'YER': '﷼',
        'BDT': '৳',
        'BTN': 'Nu.',
        'INR': '₹',
        'IDR': 'Rp',
        'LAK': '₭',
        'MYR': 'RM',
        'MMK': 'K',
        'NPR': '₨',
        'PKR': '₨',
        'PHP': '₱',
        'SGD': '$',
        'LKR': 'Rs',
        'THB': '฿',
        'VND': '₫',
        'KHR': '៛',
        'BND': '$',
        'KRW': '₩',
        'JPY': '¥',
        'CNY': '¥',
        'TWD': 'NT$',
        'HKD': '$',
        'MOP': 'P',
        'MNT': '₮',
        'KPW': '₩',
        'AUD': '$',
        'NZD': '$',
        'XPF': 'Fr',
        'XDR': 'SDR'
    }


class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False


class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    TESTING = False


class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    WTF_CSRF_ENABLED = False


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
