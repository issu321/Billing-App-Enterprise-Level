"""
Enterprise Billing & POS Platform
Main Flask Application
Developer: Mohammed Usman
"""
from flask import Flask, render_template, redirect, url_for, flash, request, jsonify, session
from flask_login import current_user
from config import config
from models import init_app, login_manager, db
from utils.logger import setup_logger
from datetime import datetime
import os

def create_app(config_name='development'):
    """Application factory"""
    app = Flask(__name__, 
                template_folder='templates',
                static_folder='static')
    
    # Load configuration
    app.config.from_object(config[config_name])
    
    # Initialize extensions
    init_app(app)
    
    # Setup logging
    setup_logger(app)
    
    # Register blueprints
    register_blueprints(app)
    
    # Context processors
    register_context_processors(app)
    
    # Error handlers
    register_error_handlers(app)
    
    # Jinja filters
    register_jinja_filters(app)
    
    # Ensure upload directories exist
    os.makedirs(os.path.join(app.root_path, 'static', 'uploads', 'products'), exist_ok=True)
    os.makedirs(os.path.join(app.root_path, 'static', 'uploads', 'logos'), exist_ok=True)
    os.makedirs(os.path.join(app.root_path, 'backups'), exist_ok=True)
    
    return app


def register_blueprints(app):
    """Register all route blueprints"""
    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.products import products_bp
    from routes.categories import categories_bp
    from routes.inventory import inventory_bp
    from routes.customers import customers_bp
    from routes.suppliers import suppliers_bp
    from routes.pos import pos_bp
    from routes.billing import billing_bp
    from routes.reports import reports_bp
    from routes.analytics import analytics_bp
    from routes.barcode import barcode_bp
    from routes.payments import payments_bp
    from routes.backup import backup_bp
    from routes.security import security_bp
    from routes.settings import settings_bp
    from routes.wizard import wizard_bp
    
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/dashboard')
    app.register_blueprint(products_bp, url_prefix='/products')
    app.register_blueprint(categories_bp, url_prefix='/categories')
    app.register_blueprint(inventory_bp, url_prefix='/inventory')
    app.register_blueprint(customers_bp, url_prefix='/customers')
    app.register_blueprint(suppliers_bp, url_prefix='/suppliers')
    app.register_blueprint(pos_bp, url_prefix='/pos')
    app.register_blueprint(billing_bp, url_prefix='/billing')
    app.register_blueprint(reports_bp, url_prefix='/reports')
    app.register_blueprint(analytics_bp, url_prefix='/analytics')
    app.register_blueprint(barcode_bp, url_prefix='/barcode')
    app.register_blueprint(payments_bp, url_prefix='/payments')
    app.register_blueprint(backup_bp, url_prefix='/backup')
    app.register_blueprint(security_bp, url_prefix='/security')
    app.register_blueprint(settings_bp, url_prefix='/settings')
    app.register_blueprint(wizard_bp, url_prefix='/wizard')


def register_context_processors(app):
    """Register template context processors"""
    from models.settings import BusinessSettings
    from services.settings_service import SettingsService
    
    @app.context_processor
    def inject_now():
        return {'now': datetime.now()}

    @app.context_processor
    def inject_globals():
        """Inject global variables into all templates"""
        context = {
            'app_name': app.config.get('APP_NAME', 'Enterprise Billing'),
            'app_version': app.config.get('APP_VERSION', '1.0.0'),
            'developer_name': app.config.get('DEVELOPER_NAME', 'Mohammed Usman'),
            'developer_mobile': app.config.get('DEVELOPER_MOBILE', '8884294749'),
            'developer_email': app.config.get('DEVELOPER_EMAIL', 'jaafreeusman@gmail.com'),
            'developer_github': app.config.get('DEVELOPER_GITHUB', 'https://github.com/issu321'),
            'developer_portfolio': app.config.get('DEVELOPER_PORTFOLIO', 'https://issu321.github.io/issu321/'),
            'developer_whatsapp': app.config.get('DEVELOPER_WHATSAPP', 'https://wa.me/918884294749'),
        }
        
        # Add business settings
        try:
            settings = SettingsService.get_settings()
            context['business_settings'] = settings
            context['business_name'] = settings.business_name or 'My Business'
            context['store_name'] = settings.store_name or 'My Store'
        except Exception:
            context['business_name'] = 'My Business'
            context['store_name'] = 'My Store'
            context['business_settings'] = None
        
        # Add current user info
        if current_user.is_authenticated:
            context['current_user'] = current_user
            context['user_roles'] = [ur.role.name for ur in current_user.roles]
        
        return context


def register_error_handlers(app):
    """Register error handlers"""
    
    @app.errorhandler(404)
    def not_found_error(error):
        if request.is_json:
            return jsonify({'success': False, 'message': 'Not found'}), 404
        return render_template('errors/404.html'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        if request.is_json:
            return jsonify({'success': False, 'message': 'Internal server error'}), 500
        return render_template('errors/500.html'), 500
    
    @app.errorhandler(403)
    def forbidden_error(error):
        if request.is_json:
            return jsonify({'success': False, 'message': 'Permission denied'}), 403
        flash('You do not have permission to access this resource.', 'danger')
        return redirect(url_for('dashboard.index'))


def register_jinja_filters(app):
    """Register custom Jinja filters"""
    from utils.helpers import format_currency, format_date, format_datetime
    
    @app.template_filter('currency')
    def currency_filter(amount):
        return format_currency(amount)
    
    @app.template_filter('format_date')
    def date_filter(date_obj):
        return format_date(date_obj)
    
    @app.template_filter('format_datetime')
    def datetime_filter(datetime_obj):
        return format_datetime(datetime_obj)


# Create the application instance
app = create_app(os.environ.get('FLASK_ENV', 'development'))


# FIX: Define user_loader here to ensure it works
@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login"""
    from models.user import User
    return User.query.get(int(user_id))


@app.route('/')
def index():
    """Root route - redirect to dashboard or wizard"""
    from services.settings_service import SettingsService
    
    if not current_user.is_authenticated:
        return redirect(url_for('auth.login'))
    
    setup_status = SettingsService.get_setup_status()
    if not setup_status['setup_completed']:
        return redirect(url_for('wizard.setup'))
    
    return redirect(url_for('dashboard.index'))


@app.route('/about')
def about():
    """About page"""
    return render_template('about.html')


@app.route('/developer')
def developer():
    """Developer page"""
    return render_template('developer.html')


@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'version': app.config.get('APP_VERSION', '1.0.0'),
        'timestamp': datetime.now().isoformat()
    })


if __name__ == '__main__':
    from datetime import datetime
    app.run(host='0.0.0.0', port=5000, debug=True)