@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1

:: ============================================
:: Billing Installation App
:: By Mohammed Usman
:: Professional Windows Environment Setup
:: ============================================

:: Color Definitions (ANSI Escape Codes)
set "ESC="
for /f "delims=#" %%a in ('"prompt #$H# & echo on & for %%b in (1) do rem"') do set "ESC=%%a"

set "RESET=%ESC%[0m"
set "BOLD=%ESC%[1m"
set "DIM=%ESC%[2m"
set "UNDERLINE=%ESC%[4m"
set "BLINK=%ESC%[5m"
set "REVERSE=%ESC%[7m"
set "HIDDEN=%ESC%[8m"

:: Foreground Colors
set "BLACK=%ESC%[30m"
set "RED=%ESC%[31m"
set "GREEN=%ESC%[32m"
set "YELLOW=%ESC%[33m"
set "BLUE=%ESC%[34m"
set "MAGENTA=%ESC%[35m"
set "CYAN=%ESC%[36m"
set "WHITE=%ESC%[37m"
set "BRIGHT_BLACK=%ESC%[90m"
set "BRIGHT_RED=%ESC%[91m"
set "BRIGHT_GREEN=%ESC%[92m"
set "BRIGHT_YELLOW=%ESC%[93m"
set "BRIGHT_BLUE=%ESC%[94m"
set "BRIGHT_MAGENTA=%ESC%[95m"
set "BRIGHT_CYAN=%ESC%[96m"
set "BRIGHT_WHITE=%ESC%[97m"

:: Background Colors
set "BG_BLACK=%ESC%[40m"
set "BG_RED=%ESC%[41m"
set "BG_GREEN=%ESC%[42m"
set "BG_YELLOW=%ESC%[43m"
set "BG_BLUE=%ESC%[44m"
set "BG_MAGENTA=%ESC%[45m"
set "BG_CYAN=%ESC%[46m"
set "BG_WHITE=%ESC%[47m"

:: ============================================
:: CONFIGURATION
:: ============================================
set "VENV_DIR=venv"
set "REQUIREMENTS=requirements.txt"
set "APP_FILE=app.py"
set "PYTHON_CMD=python"
set "ERROR_COUNT=0"
set "WARN_COUNT=0"

:: ============================================
:: UTILITY FUNCTIONS
:: ============================================

goto :MAIN

:: --------------------------------------------
:: Function: Draw Line
:: --------------------------------------------
:DRAW_LINE
set "line_char=%~1"
set "line_color=%~2"
set "line_len=%~3"
if "%~1"=="" set "line_char=─"
if "%~2"=="" set "line_color=%CYAN%"
if "%~3"=="" set "line_len=78"
set "line_str="
for /l %%i in (1,1,%line_len%) do set "line_str=!line_str!!line_char!"
echo %line_color%%line_str%%RESET%
exit /b

:: --------------------------------------------
:: Function: Center Text
:: --------------------------------------------
:CENTER_TEXT
set "text=%~1"
set "text_color=%~2"
set "total_width=80"
set "text_len=0"
if "%~2"=="" set "text_color=%WHITE%"

:: Calculate text length (approximate for ASCII)
for %%a in ("%text%") do (
    set "str=%%~a"
    set "text_len=0"
    :strlen_loop
    if not "!str!"=="" (
        set "str=!str:~1!"
        set /a text_len+=1
        goto strlen_loop
    )
)

set /a padding=(total_width - text_len) / 2
set "spaces="
for /l %%i in (1,1,%padding%) do set "spaces=!spaces! "
echo %spaces%%text_color%%text%%RESET%
exit /b

:: --------------------------------------------
:: Function: Animated Header
:: --------------------------------------------
:ANIMATED_HEADER
cls
echo.
call :DRAW_LINE "═" "%BRIGHT_BLUE%" "80"
echo.
call :CENTER_TEXT "╔══════════════════════════════════════════════════════════════╗" "%BRIGHT_CYAN%"
call :CENTER_TEXT "║                                                              ║" "%BRIGHT_CYAN%"
call :CENTER_TEXT "║          BILLING INSTALLATION APP                            ║" "%BRIGHT_YELLOW%"
call :CENTER_TEXT "║                                                              ║" "%BRIGHT_CYAN%"
call :CENTER_TEXT "║              By Mohammed Usman                               ║" "%BRIGHT_GREEN%"
call :CENTER_TEXT "║                                                              ║" "%BRIGHT_CYAN%"
call :CENTER_TEXT "╚══════════════════════════════════════════════════════════════╝" "%BRIGHT_CYAN%"
echo.
call :DRAW_LINE "═" "%BRIGHT_BLUE%" "80"
echo.
exit /b

:: --------------------------------------------
:: Function: Status Box
:: --------------------------------------------
:STATUS_BOX
set "status_type=%~1"
set "status_msg=%~2"
set "status_color=%~3"
if "%~3"=="" (
    if /i "%status_type%"=="SUCCESS" set "status_color=%BRIGHT_GREEN%"
    if /i "%status_type%"=="ERROR" set "status_color=%BRIGHT_RED%"
    if /i "%status_type%"=="WARNING" set "status_color=%BRIGHT_YELLOW%"
    if /i "%status_type%"=="INFO" set "status_color=%BRIGHT_BLUE%"
    if /i "%status_type%"=="PROCESS" set "status_color=%BRIGHT_CYAN%"
)
set "prefix="
if /i "%status_type%"=="SUCCESS" set "prefix=[ ✓ ]"
if /i "%status_type%"=="ERROR" set "prefix=[ ✗ ]"
if /i "%status_type%"=="WARNING" set "prefix=[ ! ]"
if /i "%status_type%"=="INFO" set "prefix=[ i ]"
if /i "%status_type%"=="PROCESS" set "prefix=[ → ]"
echo  %status_color%%prefix% %status_msg%%RESET%
exit /b

:: --------------------------------------------
:: Function: Animated Progress Bar
:: --------------------------------------------
:PROGRESS_BAR
set "pb_label=%~1"
set "pb_percent=%~2"
set "pb_width=%~3"
if "%~3"=="" set "pb_width=50"
set /a filled=(pb_percent * pb_width) / 100
set /a empty=pb_width - filled
set "bar="
for /l %%i in (1,1,%filled%) do set "bar=!bar!█"
for /l %%i in (1,1,%empty%) do set "bar=!bar!░"
if %pb_percent%==100 (
    echo  %BRIGHT_BLUE%[ %pb_label% ]%RESET%  %BRIGHT_GREEN%[%bar%]%RESET%  %BRIGHT_GREEN%%pb_percent%%% %BRIGHT_GREEN%COMPLETE%RESET%
) else (
    echo  %BRIGHT_BLUE%[ %pb_label% ]%RESET%  %BRIGHT_YELLOW%[%bar%]%RESET%  %BRIGHT_YELLOW%%pb_percent%%% %RESET%
)
exit /b

:: --------------------------------------------
:: Function: Spinner Animation
:: --------------------------------------------
:SPINNER
set "spin_msg=%~1"
set "spin_color=%~2"
if "%~2"=="" set "spin_color=%BRIGHT_CYAN%"
set "spin_chars=⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
set "spin_idx=0"
for /l %%i in (1,1,10) do (
    set /a spin_idx=%%i %% 10
    for /f "delims=" %%a in ("!spin_chars:~%%i,1!") do (
        <nul set /p "=%spin_color%  %%a %spin_msg%...%RESET%!"
        timeout /t 1 /nobreak >nul 2>&1
        <nul set /p "=%ESC%[2K%ESC%[1G"
    )
)
exit /b

:: --------------------------------------------
:: Function: Loading Animation
:: --------------------------------------------
:LOADING_ANIM
set "load_msg=%~1"
set "load_steps=%~2"
if "%~2"=="" set "load_steps=5"
set "load_color=%~3"
if "%~3"=="" set "load_color=%BRIGHT_CYAN%"
for /l %%i in (1,1,%load_steps%) do (
    set /a pct=%%i * 100 / load_steps
    call :PROGRESS_BAR "%load_msg%" !pct!
    timeout /t 1 /nobreak >nul 2>&1
)
exit /b

:: --------------------------------------------
:: Function: Error Handler
:: --------------------------------------------
:HANDLE_ERROR
set "err_msg=%~1"
set "err_code=%~2"
if "%~2"=="" set "err_code=1"
set /a ERROR_COUNT+=1
echo.
call :STATUS_BOX "ERROR" "%err_msg%" "%BRIGHT_RED%"
echo.
echo  %RED%════════════════════════════════════════════════════════════════════════════════%RESET%
echo  %RED%  INSTALLATION FAILED WITH ERROR CODE: %err_code%%RESET%
echo  %RED%════════════════════════════════════════════════════════════════════════════════%RESET%
echo.
echo  %YELLOW%Press any key to exit...%RESET%
pause >nul
exit /b %err_code%

:: --------------------------------------------
:: Function: Warning Handler
:: --------------------------------------------
:HANDLE_WARNING
set "warn_msg=%~1"
set /a WARN_COUNT+=1
call :STATUS_BOX "WARNING" "%warn_msg%" "%BRIGHT_YELLOW%"
exit /b

:: ============================================
:: MAIN EXECUTION
:: ============================================
:MAIN

call :ANIMATED_HEADER

echo  %BRIGHT_BLUE%╔══════════════════════════════════════════════════════════════════════════════╗%RESET%
echo  %BRIGHT_BLUE%║%RESET%  %BRIGHT_WHITE%System Initialization%RESET%                                                          %BRIGHT_BLUE%║%RESET%
echo  %BRIGHT_BLUE%╚══════════════════════════════════════════════════════════════════════════════╝%RESET%
echo.

:: Check Python Installation
call :STATUS_BOX "INFO" "Detecting Python installation..." "%BRIGHT_BLUE%"
%PYTHON_CMD% --version >nul 2>&1
if errorlevel 1 (
    call :HANDLE_ERROR "Python is not installed or not found in PATH. Please install Python 3.8+ and try again." 2
)
for /f "tokens=*" %%a in ('%PYTHON_CMD% --version 2^>^&1') do set "PY_VERSION=%%a"
call :STATUS_BOX "SUCCESS" "Python detected: %PY_VERSION%"
echo.

:: Check if requirements.txt exists
call :STATUS_BOX "INFO" "Checking for %REQUIREMENTS%..." "%BRIGHT_BLUE%"
if not exist "%REQUIREMENTS%" (
    call :HANDLE_WARNING "%REQUIREMENTS% not found. Skipping package installation."
) else (
    call :STATUS_BOX "SUCCESS" "%REQUIREMENTS% found."
)
echo.

:: Check if app.py exists
call :STATUS_BOX "INFO" "Checking for %APP_FILE%..." "%BRIGHT_BLUE%"
if not exist "%APP_FILE%" (
    call :HANDLE_ERROR "%APP_FILE% not found in current directory. Please ensure your application file exists." 3
)
call :STATUS_BOX "SUCCESS" "%APP_FILE% found."
echo.

:: ============================================
:: VIRTUAL ENVIRONMENT SETUP
:: ============================================
call :DRAW_LINE "═" "%BRIGHT_BLUE%" "80"
echo.
echo  %BRIGHT_BLUE%╔══════════════════════════════════════════════════════════════════════════════╗%RESET%
echo  %BRIGHT_BLUE%║%RESET%  %BRIGHT_WHITE%Virtual Environment Setup%RESET%                                                    %BRIGHT_BLUE%║%RESET%
echo  %BRIGHT_BLUE%╚══════════════════════════════════════════════════════════════════════════════╝%RESET%
echo.

if exist "%VENV_DIR%\Scripts\activate.bat" (
    call :STATUS_BOX "INFO" "Virtual environment already exists at '%VENV_DIR%'." "%BRIGHT_BLUE%"
    call :STATUS_BOX "WARNING" "Using existing virtual environment. Skipping creation." "%BRIGHT_YELLOW%"
    set "VENV_EXISTS=1"
) else (
    call :STATUS_BOX "INFO" "Creating virtual environment in '%VENV_DIR%'..." "%BRIGHT_BLUE%"
    call :LOADING_ANIM "Creating VENV" 3 "%BRIGHT_CYAN%"

    %PYTHON_CMD% -m venv "%VENV_DIR%" >nul 2>&1
    if errorlevel 1 (
        call :HANDLE_ERROR "Failed to create virtual environment. Ensure you have 'venv' module available." 4
    )
    call :STATUS_BOX "SUCCESS" "Virtual environment created successfully."
    set "VENV_EXISTS=0"
)
echo.

:: Display VENV Confirmation
echo  %BRIGHT_GREEN%┌──────────────────────────────────────────────────────────────────────────────┐%RESET%
echo  %BRIGHT_GREEN%│%RESET%  %BRIGHT_WHITE%VENV CONFIRMATION%RESET%                                                            %BRIGHT_GREEN%│%RESET%
echo  %BRIGHT_GREEN%├──────────────────────────────────────────────────────────────────────────────┤%RESET%
echo  %BRIGHT_GREEN%│%RESET%  %CYAN%Location:%RESET%    %BRIGHT_WHITE%%CD%\%VENV_DIR%%RESET%                                          %BRIGHT_GREEN%│%RESET%
echo  %BRIGHT_GREEN%│%RESET%  %CYAN%Python:%RESET%      %BRIGHT_WHITE%%VENV_DIR%\Scripts\python.exe%RESET%                                %BRIGHT_GREEN%│%RESET%
echo  %BRIGHT_GREEN%│%RESET%  %CYAN%Pip:%RESET%         %BRIGHT_WHITE%%VENV_DIR%\Scripts\pip.exe%RESET%                                    %BRIGHT_GREEN%│%RESET%
echo  %BRIGHT_GREEN%│%RESET%  %CYAN%Status:%RESET%      %BRIGHT_GREEN%ACTIVE AND READY%RESET%                                         %BRIGHT_GREEN%│%RESET%
echo  %BRIGHT_GREEN%└──────────────────────────────────────────────────────────────────────────────┘%RESET%
echo.

:: ============================================
:: ACTIVATE VIRTUAL ENVIRONMENT
:: ============================================
call :STATUS_BOX "INFO" "Activating virtual environment..." "%BRIGHT_BLUE%"
call "%VENV_DIR%\Scripts\activate.bat" >nul 2>&1
if errorlevel 1 (
    call :HANDLE_ERROR "Failed to activate virtual environment." 5
)
call :STATUS_BOX "SUCCESS" "Virtual environment activated."
echo.

:: ============================================
:: UPGRADE PIP
:: ============================================
call :DRAW_LINE "═" "%BRIGHT_BLUE%" "80"
echo.
echo  %BRIGHT_BLUE%╔══════════════════════════════════════════════════════════════════════════════╗%RESET%
echo  %BRIGHT_BLUE%║%RESET%  %BRIGHT_WHITE%Package Manager Upgrade%RESET%                                                      %BRIGHT_BLUE%║%RESET%
echo  %BRIGHT_BLUE%╚══════════════════════════════════════════════════════════════════════════════╝%RESET%
echo.

call :STATUS_BOX "INFO" "Upgrading pip to latest version..." "%BRIGHT_BLUE%"
call :LOADING_ANIM "Upgrading PIP" 4 "%BRIGHT_CYAN%"

python -m pip install --upgrade pip >nul 2>&1
if errorlevel 1 (
    call :HANDLE_WARNING "Pip upgrade encountered issues. Continuing with existing version."
) else (
    for /f "tokens=*" %%a in ('python -m pip --version 2^>^&1') do set "PIP_VERSION=%%a"
    call :STATUS_BOX "SUCCESS" "Pip upgraded successfully: %PIP_VERSION%"
)
echo.

:: ============================================
:: INSTALL REQUIREMENTS
:: ============================================
if exist "%REQUIREMENTS%" (
    call :DRAW_LINE "═" "%BRIGHT_BLUE%" "80"
    echo.
    echo  %BRIGHT_BLUE%╔══════════════════════════════════════════════════════════════════════════════╗%RESET%
    echo  %BRIGHT_BLUE%║%RESET%  %BRIGHT_WHITE%Dependency Installation%RESET%                                                      %BRIGHT_BLUE%║%RESET%
    echo  %BRIGHT_BLUE%╚══════════════════════════════════════════════════════════════════════════════╝%RESET%
    echo.

    call :STATUS_BOX "INFO" "Reading %REQUIREMENTS%..." "%BRIGHT_BLUE%"

    :: Count packages
    set "PKG_COUNT=0"
    for /f %%a in (%REQUIREMENTS%) do set /a PKG_COUNT+=1
    call :STATUS_BOX "INFO" "Found %PKG_COUNT% package(s) to install." "%BRIGHT_BLUE%"
    echo.

    call :STATUS_BOX "INFO" "Installing dependencies... This may take a few minutes." "%BRIGHT_BLUE%"
    echo.

    :: Install with progress simulation
    set "CUR_PKG=0"
    for /f %%a in (%REQUIREMENTS%) do (
        set /a CUR_PKG+=1
        set /a pct=CUR_PKG * 100 / PKG_COUNT
        set "pkg_name=%%a"
        call :PROGRESS_BAR "Installing !pkg_name!" !pct!

        pip install %%a >nul 2>&1
        if errorlevel 1 (
            call :HANDLE_WARNING "Failed to install %%a. Continuing with remaining packages."
        )
        timeout /t 1 /nobreak >nul 2>&1
    )

    echo.
    if %ERROR_COUNT%==0 (
        call :STATUS_BOX "SUCCESS" "All dependencies installed successfully."
    ) else (
        call :STATUS_BOX "WARNING" "Installation completed with %ERROR_COUNT% error(s). Check warnings above." "%BRIGHT_YELLOW%"
    )
    echo.
)

:: ============================================
:: FINAL VERIFICATION
:: ============================================
call :DRAW_LINE "═" "%BRIGHT_BLUE%" "80"
echo.
echo  %BRIGHT_BLUE%╔══════════════════════════════════════════════════════════════════════════════╗%RESET%
echo  %BRIGHT_BLUE%║%RESET%  %BRIGHT_WHITE%System Verification%RESET%                                                        %BRIGHT_BLUE%║%RESET%
echo  %BRIGHT_BLUE%╚══════════════════════════════════════════════════════════════════════════════╝%RESET%
echo.

call :STATUS_BOX "INFO" "Verifying installation integrity..." "%BRIGHT_BLUE%"
call :LOADING_ANIM "Verification" 3 "%BRIGHT_CYAN%"

python -c "import sys; print('Python:', sys.version)" >nul 2>&1
if errorlevel 1 (
    call :HANDLE_ERROR "Python verification failed. Installation may be corrupted." 6
)
call :STATUS_BOX "SUCCESS" "Installation integrity verified."
echo.

:: ============================================
:: LAUNCH APPLICATION
:: ============================================
call :DRAW_LINE "═" "%BRIGHT_BLUE%" "80"
echo.
echo  %BRIGHT_GREEN%╔══════════════════════════════════════════════════════════════════════════════╗%RESET%
echo  %BRIGHT_GREEN%║%RESET%  %BRIGHT_WHITE%Launching Application%RESET%                                                      %BRIGHT_GREEN%║%RESET%
echo  %BRIGHT_GREEN%╚══════════════════════════════════════════════════════════════════════════════╝%RESET%
echo.

call :STATUS_BOX "INFO" "Preparing to start %APP_FILE%..." "%BRIGHT_BLUE%"
echo.

:: Countdown
echo  %BRIGHT_YELLOW%  Starting in:%RESET%
for /l %%i in (3,-1,1) do (
    echo  %BRIGHT_YELLOW%    %%i...%RESET%
    timeout /t 1 /nobreak >nul 2>&1
)
echo.

call :STATUS_BOX "SUCCESS" "Launching %APP_FILE%..."
echo.
call :DRAW_LINE "─" "%BRIGHT_CYAN%" "80"
echo.

:: Run the application
python "%APP_FILE%"
set "APP_EXIT_CODE=%errorlevel%"

echo.
call :DRAW_LINE "─" "%BRIGHT_CYAN%" "80"
echo.

:: ============================================
:: EXIT SUMMARY
:: ============================================
if %APP_EXIT_CODE%==0 (
    echo  %BRIGHT_GREEN%╔══════════════════════════════════════════════════════════════════════════════╗%RESET%
    echo  %BRIGHT_GREEN%║%RESET%  %BRIGHT_WHITE%Application exited successfully.                                               %BRIGHT_GREEN%║%RESET%
    echo  %BRIGHT_GREEN%╚══════════════════════════════════════════════════════════════════════════════╝%RESET%
) else (
    echo  %BRIGHT_RED%╔══════════════════════════════════════════════════════════════════════════════╗%RESET%
    echo  %BRIGHT_RED%║%RESET%  %BRIGHT_WHITE%Application exited with code: %APP_EXIT_CODE%                                   %BRIGHT_RED%║%RESET%
    echo  %BRIGHT_RED%╚══════════════════════════════════════════════════════════════════════════════╝%RESET%
)

echo.
echo  %BRIGHT_BLUE%════════════════════════════════════════════════════════════════════════════════%RESET%
echo  %BRIGHT_BLUE%  Installation Summary:%RESET%
echo  %BRIGHT_BLUE%    Errors:   %RESET%%BRIGHT_RED%%ERROR_COUNT%%RESET%
echo  %BRIGHT_BLUE%    Warnings: %RESET%%BRIGHT_YELLOW%%WARN_COUNT%%RESET%
echo  %BRIGHT_BLUE%════════════════════════════════════════════════════════════════════════════════%RESET%
echo.
echo  %BRIGHT_CYAN%  Billing Installation App by Mohammed Usman%RESET%
echo  %DIM%  Thank you for using our installer.%RESET%
echo.
echo  %YELLOW%Press any key to exit...%RESET%
pause >nul

:: Deactivate venv before exit
call "%VENV_DIR%\Scripts\deactivate.bat" >nul 2>&1
endlocal
